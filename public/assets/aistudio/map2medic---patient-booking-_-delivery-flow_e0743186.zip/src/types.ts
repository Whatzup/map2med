export interface ServiceItem {
  id: string;
  title: string;
  subtitle: string;
  price: number;
  unit: string;
  category: 'injections' | 'wound' | 'vitals' | 'lab' | 'physio' | 'elder';
  imageType: string;
  duration?: string;
  description?: string;
}

export interface CartItem {
  service: ServiceItem;
  quantity: number;
}

export interface Specialist {
  name: string;
  role: string;
  rating: number;
  reviewCount: number;
  experience: string;
  phone: string;
  avatarUrl: string;
  vehicle: string;
  plateNumber: string;
  distance: string;
  etaMinutes: number;
}

export interface ServiceProgressItem {
  id: string;
  title: string;
  category: string;
  status: 'pending' | 'in_progress' | 'completed';
  timeEstimate?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'specialist' | 'user' | 'system';
  text: string;
  timestamp: string;
}

export type ScreenId = 1 | 2 | 3 | 4 | 5;
