/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PhoneFrame } from './components/PhoneFrame';
import { Screen1Home } from './components/Screen1Home';
import { Screen2Cart } from './components/Screen2Cart';
import { Screen3Assignment } from './components/Screen3Assignment';
import { Screen4Tracking } from './components/Screen4Tracking';
import { Screen5ServiceStarted } from './components/Screen5ServiceStarted';
import { PanoramicFlowView } from './components/PanoramicFlowView';
import { CallModal, ChatModal, SpecialistDetailsModal, AddressModal } from './components/Modals';
import { INITIAL_CART_ITEMS } from './data/mockData';
import { CartItem, ServiceItem, ScreenId } from './types';
import {
  Smartphone,
  Layers,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  Phone,
  CheckCircle2,
  Sparkles,
  Info
} from 'lucide-react';

export default function App() {
  const [viewMode, setViewMode] = useState<'panoramic' | 'simulator'>('panoramic');
  const [currentScreen, setCurrentScreen] = useState<ScreenId>(1);
  const [cartItems, setCartItems] = useState<CartItem[]>(INITIAL_CART_ITEMS);
  const [currentAddress, setCurrentAddress] = useState('BIS DLF Phase 5, Gurugram');

  // Modals state
  const [isCallOpen, setIsCallOpen] = useState(false);
  const [callTarget, setCallTarget] = useState<{ name: string; role: string }>({
    name: 'Amit Kumar',
    role: 'Care Specialist • RN'
  });
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isSpecialistDetailsOpen, setIsSpecialistDetailsOpen] = useState(false);
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);

  // Cart operations
  const handleSelectService = (service: ServiceItem) => {
    setCartItems((prev) => {
      const existing = prev.find((i) => i.service.id === service.id);
      if (existing) {
        return prev.map((i) =>
          i.service.id === service.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { service, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.service.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((i) => i.service.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handleResetFlow = () => {
    setCartItems(INITIAL_CART_ITEMS);
    setCurrentScreen(1);
  };

  const handleOpenSupportCall = () => {
    setCallTarget({
      name: '1-800-MAP2MEDIC Support',
      role: 'Healthcare Concierge Desk'
    });
    setIsCallOpen(true);
  };

  const handleOpenSpecialistCall = () => {
    setCallTarget({
      name: 'Amit Kumar',
      role: 'Assigned Care Specialist (RN)'
    });
    setIsCallOpen(true);
  };

  const screenNames: Record<ScreenId, string> = {
    1: '1. Home & Services',
    2: '2. My Cart',
    3: '3. Auto-Assignment',
    4: '4. Live Tracking',
    5: '5. Service Started'
  };

  return (
    <div className="min-h-screen bg-[#f3f6f5] flex flex-col text-slate-800 font-sans antialiased selection:bg-emerald-100 selection:text-emerald-900">
      {/* Top Application Navigation Bar */}
      <nav className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-2xs px-4 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Brand Logo & Name */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#064e3b] to-[#047857] flex items-center justify-center text-white shadow-sm">
              <span className="font-black text-sm tracking-wider">M2</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-slate-900 tracking-tight text-sm sm:text-base">
                  MAP2MEDIC
                </span>
                <span className="hidden sm:inline-block text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.2 rounded-full border border-emerald-200">
                  Patient Delivery Flow
                </span>
              </div>
              <p className="text-[11px] text-slate-500 hidden md:block">
                On-Demand Healthcare &amp; Home Specialist Delivery
              </p>
            </div>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setViewMode('panoramic')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                viewMode === 'panoramic'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Panoramic Flow (5 Screens)</span>
            </button>

            <button
              onClick={() => setViewMode('simulator')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                viewMode === 'simulator'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Interactive Phone</span>
            </button>
          </div>

          {/* Actions: Hotline & Reset */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleOpenSupportCall}
              className="hidden lg:flex items-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200/90 text-xs font-bold px-3 py-1.5 rounded-lg transition-all active:scale-95 shadow-2xs"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-700" />
              <span>1-800-MAP2MEDIC</span>
            </button>

            <button
              onClick={handleResetFlow}
              className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors"
              title="Reset flow to Screen 1"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </nav>

      {/* Screen Selector Secondary Bar (Tabs to quickly jump to any of the 5 screens) */}
      <div className="bg-white/80 border-b border-slate-200 px-4 py-2">
        <div className="max-w-5xl mx-auto flex items-center justify-between gap-2 overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-1.5 min-w-max">
            <span className="text-[11px] font-bold text-slate-500 mr-1 hidden sm:inline">Jump to:</span>
            {([1, 2, 3, 4, 5] as ScreenId[]).map((scrId) => {
              const isActive = currentScreen === scrId;
              return (
                <button
                  key={scrId}
                  onClick={() => {
                    setCurrentScreen(scrId);
                    if (viewMode === 'panoramic') {
                      // Also support opening in simulator
                    }
                  }}
                  className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-[#084d3e] text-white shadow-xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-emerald-300' : 'bg-slate-400'}`}></span>
                  <span>{screenNames[scrId]}</span>
                </button>
              );
            })}
          </div>

          {viewMode === 'simulator' && (
            <div className="flex items-center gap-1 shrink-0">
              <button
                disabled={currentScreen === 1}
                onClick={() => setCurrentScreen((prev) => Math.max(1, prev - 1) as ScreenId)}
                className="px-2 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 disabled:opacity-30 disabled:pointer-events-none flex items-center gap-0.5"
              >
                <ArrowLeft className="w-3 h-3" />
                <span>Prev</span>
              </button>
              <button
                disabled={currentScreen === 5}
                onClick={() => setCurrentScreen((prev) => Math.min(5, prev + 1) as ScreenId)}
                className="px-2 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 disabled:opacity-30 disabled:pointer-events-none flex items-center gap-0.5"
              >
                <span>Next</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col items-center justify-start py-4">
        {viewMode === 'panoramic' ? (
          /* Side-by-side Panoramic flow replicating the reference image exactly */
          <PanoramicFlowView
            cartItems={cartItems}
            onSelectService={handleSelectService}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveItem={handleRemoveItem}
            onClearCart={handleClearCart}
            onFocusScreen={(s) => {
              setCurrentScreen(s);
              setViewMode('simulator');
            }}
            onCallSpecialist={handleOpenSpecialistCall}
            onChatSpecialist={() => setIsChatOpen(true)}
            onViewDetails={() => setIsSpecialistDetailsOpen(true)}
            onAddressClick={() => setIsAddressModalOpen(true)}
            onCallSupportClick={handleOpenSupportCall}
          />
        ) : (
          /* Single Interactive Phone Simulator */
          <div className="w-full flex flex-col items-center py-4 px-4">
            <div className="text-center mb-4 max-w-md">
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-200">
                Interactive Simulator • Screen {currentScreen} of 5
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
                {screenNames[currentScreen]}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Click buttons, adjust quantities, place bookings, track routes, and simulate care delivery in real time!
              </p>
            </div>

            <PhoneFrame
              screenNumber={currentScreen}
              screenLabel={`SCREEN ${currentScreen} • ${screenNames[currentScreen]}`}
              isActive={true}
            >
              {currentScreen === 1 && (
                <Screen1Home
                  cartCount={cartItems.length}
                  onSelectService={handleSelectService}
                  onNavigateToCart={() => setCurrentScreen(2)}
                  onNavigateToTracking={() => setCurrentScreen(4)}
                  onAddressClick={() => setIsAddressModalOpen(true)}
                  onCallSupportClick={handleOpenSupportCall}
                />
              )}

              {currentScreen === 2 && (
                <Screen2Cart
                  cartItems={cartItems}
                  onUpdateQuantity={handleUpdateQuantity}
                  onRemoveItem={handleRemoveItem}
                  onClearCart={handleClearCart}
                  onAddMore={() => setCurrentScreen(1)}
                  onProceedToBooking={() => setCurrentScreen(3)}
                  onBackToHome={() => setCurrentScreen(1)}
                  onAddressClick={() => setIsAddressModalOpen(true)}
                  onCallSupportClick={handleOpenSupportCall}
                />
              )}

              {currentScreen === 3 && (
                <Screen3Assignment
                  onSpecialistAssigned={() => setCurrentScreen(4)}
                  onAddressClick={() => setIsAddressModalOpen(true)}
                  onCallSupportClick={handleOpenSupportCall}
                />
              )}

              {currentScreen === 4 && (
                <Screen4Tracking
                  onCallSpecialist={handleOpenSpecialistCall}
                  onChatSpecialist={() => setIsChatOpen(true)}
                  onViewDetails={() => setIsSpecialistDetailsOpen(true)}
                  onManageBooking={() => setCurrentScreen(3)}
                  onSpecialistArrived={() => setCurrentScreen(5)}
                  onAddressClick={() => setIsAddressModalOpen(true)}
                  onCallSupportClick={handleOpenSupportCall}
                />
              )}

              {currentScreen === 5 && (
                <Screen5ServiceStarted
                  onCallSpecialist={handleOpenSpecialistCall}
                  onChatSpecialist={() => setIsChatOpen(true)}
                  onViewDetails={() => setIsSpecialistDetailsOpen(true)}
                  onAddressClick={() => setIsAddressModalOpen(true)}
                  onCallSupportClick={handleOpenSupportCall}
                  onResetFlow={handleResetFlow}
                />
              )}
            </PhoneFrame>

            {/* Stepper Navigation Under Phone */}
            <div className="flex items-center gap-2 mt-6">
              {([1, 2, 3, 4, 5] as ScreenId[]).map((scr) => (
                <button
                  key={scr}
                  onClick={() => setCurrentScreen(scr)}
                  className={`w-8 h-8 rounded-full font-bold text-xs flex items-center justify-center transition-all ${
                    currentScreen === scr
                      ? 'bg-[#084d3e] text-white ring-4 ring-emerald-500/20 shadow-md scale-110'
                      : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-300'
                  }`}
                >
                  {scr}
                </button>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Global Interactive Modals */}
      <CallModal
        isOpen={isCallOpen}
        onClose={() => setIsCallOpen(false)}
        callerName={callTarget.name}
        callerRole={callTarget.role}
      />

      <ChatModal
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
      />

      <SpecialistDetailsModal
        isOpen={isSpecialistDetailsOpen}
        onClose={() => setIsSpecialistDetailsOpen(false)}
        onCall={handleOpenSpecialistCall}
        onChat={() => {
          setIsSpecialistDetailsOpen(false);
          setIsChatOpen(true);
        }}
      />

      <AddressModal
        isOpen={isAddressModalOpen}
        onClose={() => setIsAddressModalOpen(false)}
        selectedAddress={currentAddress}
        onSelectAddress={(addr) => setCurrentAddress(addr)}
      />
    </div>
  );
}
