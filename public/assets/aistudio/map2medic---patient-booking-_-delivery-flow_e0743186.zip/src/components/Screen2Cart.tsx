import React from 'react';
import { ChevronLeft, Trash2, Plus, Minus, Info, Users, Sparkles, ArrowRight } from 'lucide-react';
import { HeaderBar } from './HeaderBar';
import { BottomNavBar } from './BottomNavBar';
import {
  InjectionProcedureIllustration,
  IVDripProcedureIllustration,
  VaccineProcedureIllustration,
  IMIProcedureIllustration,
  BloodSampleIllustration,
  PhysioIllustration
} from './MedicalIllustrations';
import { CartItem } from '../types';

interface Screen2CartProps {
  cartItems: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
  onAddMore: () => void;
  onProceedToBooking: () => void;
  onBackToHome: () => void;
  onAddressClick?: () => void;
  onCallSupportClick?: () => void;
}

export const Screen2Cart: React.FC<Screen2CartProps> = ({
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onAddMore,
  onProceedToBooking,
  onBackToHome,
  onAddressClick,
  onCallSupportClick
}) => {
  const subTotal = cartItems.reduce((acc, item) => acc + item.service.price * item.quantity, 0);
  const convenienceFee = cartItems.length > 0 ? 90 : 0;
  const totalAmount = subTotal + convenienceFee;

  const renderThumbnail = (imageType: string) => {
    switch (imageType) {
      case 'iv-drip':
        return <IVDripProcedureIllustration size={54} />;
      case 'vaccine':
        return <VaccineProcedureIllustration size={54} />;
      case 'im-injection':
        return <IMIProcedureIllustration size={54} />;
      case 'blood-test':
      case 'lab':
        return <BloodSampleIllustration size={54} />;
      case 'physio':
        return <PhysioIllustration size={54} />;
      case 'injection':
      default:
        return <InjectionProcedureIllustration size={54} />;
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#f8faf9] text-slate-800 text-left">
      {/* Top Header */}
      <HeaderBar onAddressClick={onAddressClick} onCallSupportClick={onCallSupportClick} />

      {/* Cart Title Bar */}
      <div className="px-4 py-2 bg-white border-b border-slate-100 flex items-center justify-between">
        <button
          onClick={onBackToHome}
          className="flex items-center gap-1.5 text-slate-900 font-bold text-xs hover:text-emerald-800 transition-colors"
        >
          <ChevronLeft className="w-4 h-4 stroke-[2.5]" />
          <span>My Cart ({cartItems.length} Services)</span>
        </button>

        {cartItems.length > 0 && (
          <button
            onClick={onClearCart}
            className="text-[10.5px] font-semibold text-slate-500 hover:text-rose-600 transition-colors"
          >
            Clear All
          </button>
        )}
      </div>

      {/* Scrollable Cart Content */}
      <div className="flex-1 overflow-y-auto px-3.5 py-3 space-y-3 scrollbar-thin">
        {/* Cart Items List */}
        {cartItems.length === 0 ? (
          <div className="bg-white rounded-xl p-8 text-center border border-slate-200">
            <p className="text-xs text-slate-500 font-medium mb-3">Your cart is currently empty</p>
            <button
              onClick={onAddMore}
              className="bg-[#084d3e] text-white text-xs font-bold px-4 py-2 rounded-lg shadow-sm"
            >
              Browse Services
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {cartItems.map((item) => (
              <div
                key={item.service.id}
                className="bg-white rounded-xl p-3 border border-slate-200/80 shadow-2xs flex items-center justify-between gap-2.5"
              >
                {/* Left: Illustration Thumbnail */}
                <div className="w-14 h-14 bg-emerald-50/70 rounded-lg shrink-0 flex items-center justify-center overflow-hidden border border-emerald-100">
                  {renderThumbnail(item.service.imageType)}
                </div>

                {/* Middle: Details */}
                <div className="flex-1 min-w-0">
                  <h4 className="text-[11.5px] font-bold text-slate-900 truncate">
                    {item.service.title}
                  </h4>
                  <p className="text-[9.5px] text-slate-500 truncate mt-0.5">
                    {item.service.subtitle}
                  </p>
                  <div className="mt-1 flex items-center gap-1.5">
                    <span className="text-xs font-black text-slate-900">
                      ₹{item.service.price * item.quantity}
                    </span>
                    {item.quantity > 1 && (
                      <span className="text-[9px] text-slate-400">
                        (₹{item.service.price} each)
                      </span>
                    )}
                  </div>
                </div>

                {/* Right: Quantity Stepper & Delete */}
                <div className="flex flex-col items-end gap-2 shrink-0">
                  <button
                    onClick={() => onRemoveItem(item.service.id)}
                    className="text-slate-400 hover:text-rose-500 p-0.5 transition-colors"
                    title="Remove item"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>

                  <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-md px-1.5 py-0.5 shadow-2xs">
                    <button
                      onClick={() => onUpdateQuantity(item.service.id, -1)}
                      className="p-0.5 text-slate-600 hover:text-slate-900 active:scale-90"
                      title="Decrease quantity"
                    >
                      <Minus className="w-2.5 h-2.5" />
                    </button>
                    <span className="text-[11px] font-bold text-slate-900 min-w-[12px] text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => onUpdateQuantity(item.service.id, 1)}
                      className="p-0.5 text-slate-600 hover:text-slate-900 active:scale-90"
                      title="Increase quantity"
                    >
                      <Plus className="w-2.5 h-2.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Add More Services Button */}
        <button
          onClick={onAddMore}
          className="w-full py-2 bg-white hover:bg-emerald-50/50 border border-dashed border-emerald-500/60 rounded-xl text-emerald-800 text-[11px] font-bold flex items-center justify-center gap-1.5 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add More Services</span>
        </button>

        {/* Assignment Notice Banner */}
        <div className="bg-emerald-50/80 border border-emerald-200/90 rounded-xl p-2.5 flex items-center gap-2.5 shadow-2xs">
          <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
            <Users className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="flex-1">
            <h5 className="text-[10.5px] font-bold text-emerald-950 leading-tight">
              Care will be assigned automatically
            </h5>
            <p className="text-[9px] text-emerald-800/80 font-medium leading-tight mt-0.5">
              Based on certified skills, safety verification & distance
            </p>
          </div>
        </div>

        {/* Bill Summary Breakdown */}
        <div className="bg-white rounded-xl p-3 border border-slate-200/80 shadow-2xs space-y-2 text-xs">
          <div className="flex items-center justify-between text-slate-600 text-[11px]">
            <span>Sub Total</span>
            <span className="font-semibold text-slate-800">₹{subTotal}</span>
          </div>

          <div className="flex items-center justify-between text-slate-600 text-[11px]">
            <span className="flex items-center gap-1">
              <span>Convenience Fee</span>
              <Info className="w-3 h-3 text-slate-400" />
            </span>
            <span className="font-semibold text-slate-800">₹{convenienceFee}</span>
          </div>

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between font-bold text-slate-900">
            <span className="text-xs">Total Amount</span>
            <span className="text-sm font-black text-emerald-950">₹{totalAmount}</span>
          </div>
        </div>

        {/* Primary Checkout CTA Button */}
        <button
          onClick={onProceedToBooking}
          disabled={cartItems.length === 0}
          className="w-full bg-[#084d3e] hover:bg-[#063f33] disabled:opacity-50 text-white font-bold py-3 px-4 rounded-xl shadow-md flex items-center justify-between transition-all active:scale-[0.99]"
        >
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-wide">Proceed to Book</span>
            <span className="text-emerald-300/60">|</span>
            <span className="text-sm font-extrabold text-white">₹{totalAmount}</span>
          </div>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Bottom Nav */}
      <BottomNavBar activeTab="home" />
    </div>
  );
};
