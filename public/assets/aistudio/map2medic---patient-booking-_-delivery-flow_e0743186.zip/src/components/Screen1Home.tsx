import React, { useState } from 'react';
import { Search, SlidersHorizontal, ChevronRight, CheckCircle2, ShieldCheck, Plus, ArrowRight } from 'lucide-react';
import { HeaderBar } from './HeaderBar';
import { BottomNavBar } from './BottomNavBar';
import {
  NurseDoctorIllustration,
  InjectionsCategoryIcon,
  WoundCareCategoryIcon,
  VitalsCategoryIcon,
  LabTestsCategoryIcon,
  PhysioCategoryIcon,
  ElderCareCategoryIcon,
  InjectionProcedureIllustration,
  IVDripProcedureIllustration,
  VaccineProcedureIllustration,
  IMIProcedureIllustration
} from './MedicalIllustrations';
import { INJECTION_SERVICES, POPULAR_CATEGORIES } from '../data/mockData';
import { ServiceItem } from '../types';

interface Screen1HomeProps {
  onSelectService?: (service: ServiceItem) => void;
  onNavigateToCart?: () => void;
  onNavigateToTracking?: () => void;
  onAddressClick?: () => void;
  onCallSupportClick?: () => void;
  cartCount?: number;
}

export const Screen1Home: React.FC<Screen1HomeProps> = ({
  onSelectService,
  onNavigateToCart,
  onNavigateToTracking,
  onAddressClick,
  onCallSupportClick,
  cartCount = 3
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('injections');

  const renderCategoryIcon = (catId: string) => {
    switch (catId) {
      case 'injections':
        return <InjectionsCategoryIcon size={34} />;
      case 'wound':
        return <WoundCareCategoryIcon size={34} />;
      case 'vitals':
        return <VitalsCategoryIcon size={34} />;
      case 'lab':
        return <LabTestsCategoryIcon size={34} />;
      case 'physio':
        return <PhysioCategoryIcon size={34} />;
      case 'elder':
        return <ElderCareCategoryIcon size={34} />;
      default:
        return <InjectionsCategoryIcon size={34} />;
    }
  };

  const renderServiceCardIllustration = (imageType: string) => {
    switch (imageType) {
      case 'iv-drip':
        return <IVDripProcedureIllustration size={64} />;
      case 'vaccine':
        return <VaccineProcedureIllustration size={64} />;
      case 'im-injection':
        return <IMIProcedureIllustration size={64} />;
      case 'injection':
      default:
        return <InjectionProcedureIllustration size={64} />;
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#f8faf9] text-slate-800 text-left">
      {/* Top Header */}
      <HeaderBar onAddressClick={onAddressClick} onCallSupportClick={onCallSupportClick} />

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-3.5 py-3 space-y-3.5 scrollbar-thin">
        {/* Hero Card: Visit Confirmed */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#064e3b] via-[#065f46] to-[#047857] text-white p-4 shadow-lg border border-emerald-800">
          {/* Subtle background glow */}
          <div className="absolute -right-8 -top-8 w-36 h-36 bg-emerald-400/20 rounded-full blur-xl pointer-events-none"></div>

          <div className="relative z-10 pr-24">
            <span className="text-[10px] tracking-wider text-emerald-200/90 font-mono font-medium uppercase block">
              REF 023-2353-81 M
            </span>

            <div className="flex items-center gap-1.5 mt-1">
              <h2 className="text-base font-extrabold tracking-tight">Visit Confirmed</h2>
              <CheckCircle2 className="w-4 h-4 text-emerald-300 fill-emerald-300/30" />
            </div>

            <p className="text-[11px] text-emerald-100 font-medium mt-0.5">
              Care Specialist • On the way
            </p>

            <button
              onClick={onNavigateToTracking}
              className="mt-3 inline-flex items-center gap-1 bg-white hover:bg-emerald-50 text-emerald-900 text-[10.5px] font-bold px-3 py-1.5 rounded-full shadow-sm transition-all active:scale-95"
            >
              <span>Track / Manage Booking</span>
              <ChevronRight className="w-3 h-3 text-emerald-900" />
            </button>
          </div>

          {/* 3D Nurse Doctor Character on Right */}
          <div className="absolute -right-1 -bottom-2 pointer-events-none transform scale-90 origin-bottom-right">
            <NurseDoctorIllustration size={110} />
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative flex items-center">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search injections, dressing, checkups..."
            className="w-full bg-white border border-slate-200/90 rounded-xl pl-9 pr-10 py-2 text-xs placeholder:text-slate-400 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600 shadow-2xs"
          />
          <button
            className="absolute right-3 p-1 text-slate-400 hover:text-slate-600"
            title="Filter options"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Category Grid: "What do you need today?" */}
        <section>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-bold text-slate-900 tracking-tight">What do you need today?</h3>
          </div>

          <div className="grid grid-cols-6 gap-1.5">
            {POPULAR_CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`flex flex-col items-center p-1.5 rounded-xl transition-all border ${
                    isSelected
                      ? 'bg-emerald-50 border-emerald-400 shadow-xs ring-2 ring-emerald-500/20 scale-102'
                      : 'bg-white border-slate-200/80 hover:border-slate-300 shadow-2xs hover:scale-101'
                  }`}
                  title={cat.name}
                >
                  <div className="flex items-center justify-center mb-1 drop-shadow-xs">
                    {renderCategoryIcon(cat.id)}
                  </div>
                  <span className={`text-[9px] leading-tight text-center truncate w-full ${
                    isSelected ? 'font-bold text-emerald-900' : 'font-semibold text-slate-700'
                  }`}>
                    {cat.name}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Services for Injections */}
        <section className="relative">
          <div className="flex items-center justify-between mb-1.5">
            <div>
              <h3 className="text-xs font-bold text-slate-900 tracking-tight">Services for Injections</h3>
              <p className="text-[9.5px] text-slate-500 font-medium">Daily • Regular • At Home</p>
            </div>
            <button
              onClick={onNavigateToCart}
              className="text-[10px] font-bold text-emerald-800 hover:underline flex items-center gap-0.5"
            >
              <span>View Cart ({cartCount})</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {INJECTION_SERVICES.map((serv, index) => {
              const isLastCard = index === 3; // Card with the hand tapping cue
              return (
                <div
                  key={serv.id}
                  className="relative bg-white rounded-xl p-2.5 border border-slate-200/80 shadow-2xs flex flex-col justify-between hover:border-emerald-300 hover:shadow-xs transition-all group"
                >
                  {/* Distinct Service Illustration */}
                  <div className="w-full h-20 rounded-lg flex items-center justify-center overflow-hidden mb-2 relative shadow-2xs">
                    {renderServiceCardIllustration(serv.imageType)}
                  </div>

                  {/* Title & Subtitle */}
                  <div>
                    <h4 className="text-[11px] font-bold text-slate-900 leading-tight line-clamp-1">
                      {serv.title}
                    </h4>
                    <p className="text-[9px] text-slate-500 line-clamp-1 mt-0.5">
                      {serv.subtitle}
                    </p>
                  </div>

                  {/* Price & Book Button */}
                  <div className="mt-2.5 flex items-center justify-between gap-1 pt-1 border-t border-slate-100">
                    <div>
                      <span className="text-xs font-black text-slate-900">₹{serv.price}</span>
                      <span className="text-[9px] text-slate-400 font-normal"> /{serv.unit}</span>
                    </div>

                    <div className="relative">
                      <button
                        onClick={() => {
                          onSelectService?.(serv);
                          onNavigateToCart?.();
                        }}
                        className="bg-[#084d3e] hover:bg-[#064034] active:scale-95 text-white text-[10px] font-bold px-2.5 py-1 rounded-md transition-all shadow-2xs flex items-center gap-1"
                      >
                        <Plus className="w-2.5 h-2.5" />
                        <span>Book Now</span>
                      </button>

                      {/* Interactive Pointing Hand from Reference Image on the 4th item */}
                      {isLastCard && (
                        <div
                          onClick={() => {
                            onSelectService?.(serv);
                            onNavigateToCart?.();
                          }}
                          className="absolute -bottom-4 -right-2 z-30 cursor-pointer animate-bounce pointer-events-auto"
                          title="Click to proceed to Cart"
                        >
                          <div className="relative flex items-center justify-center">
                            {/* Pulse ring */}
                            <span className="absolute w-8 h-8 rounded-full bg-emerald-500/30 animate-ping"></span>
                            {/* Pointer hand SVG */}
                            <svg width="42" height="42" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <circle cx="50" cy="50" r="42" fill="#0284c7" fillOpacity="0.15" />
                              <circle cx="50" cy="50" r="28" fill="#0369a1" fillOpacity="0.25" />
                              {/* Hand */}
                              <path
                                d="M48 20 C48 16 54 16 54 20 L54 50 L60 50 C65 50 68 54 68 58 L68 64 C68 76 58 84 46 84 C36 84 28 78 28 66 L28 54 C28 48 34 46 38 50 L42 54 L42 20 C42 16 48 16 48 20 Z"
                                fill="#fed7aa"
                                stroke="#c2410c"
                                strokeWidth="3"
                                strokeLinejoin="round"
                              />
                            </svg>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Trust & Safety Banner */}
        <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-xl p-3 flex items-center gap-2.5 shadow-2xs">
          <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center shrink-0 shadow-xs">
            <ShieldCheck className="w-5 h-5 text-emerald-100" />
          </div>
          <div className="text-left">
            <h5 className="text-[11px] font-bold text-emerald-950 leading-tight">
              Safe. Reliable. At Your Doorstep.
            </h5>
            <p className="text-[9.5px] text-emerald-800/80 leading-snug mt-0.5 font-medium">
              Verified professionals • Hygienic kits • Care you can trust
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Nav */}
      <BottomNavBar activeTab="home" onTabChange={(t) => t === 'orders' ? onNavigateToTracking?.() : undefined} />
    </div>
  );
};
