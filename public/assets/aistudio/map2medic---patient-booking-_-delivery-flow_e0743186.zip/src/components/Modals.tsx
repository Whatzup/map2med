import React, { useState, useEffect } from 'react';
import { X, Phone, PhoneOff, Mic, Volume2, Grid, Send, Star, ShieldCheck, MapPin, Calendar, Clock, CheckCircle } from 'lucide-react';
import { ASSIGNED_SPECIALIST, ADDRESSES } from '../data/mockData';
import { ChatMessage } from '../types';

interface CallModalProps {
  isOpen: boolean;
  onClose: () => void;
  callerName?: string;
  callerRole?: string;
  callerAvatar?: string;
}

export const CallModal: React.FC<CallModalProps> = ({
  isOpen,
  onClose,
  callerName = ASSIGNED_SPECIALIST.name,
  callerRole = 'Care Specialist • RN',
  callerAvatar = ASSIGNED_SPECIALIST.avatarUrl
}) => {
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeaker, setIsSpeaker] = useState(true);

  useEffect(() => {
    if (!isOpen) {
      setCallDuration(0);
      return;
    }
    const timer = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen) return null;

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${rem.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-gradient-to-b from-slate-900 via-slate-900 to-[#042f2e] text-white rounded-3xl p-6 shadow-2xl flex flex-col items-center border border-slate-700 animate-in fade-in zoom-in-95 duration-200">
        {/* Top bar indicator */}
        <div className="w-12 h-1 bg-slate-700 rounded-full mb-6"></div>

        <span className="text-xs uppercase tracking-widest text-emerald-400 font-bold mb-1">
          Connected Call
        </span>
        <span className="text-sm font-mono text-slate-300 mb-6">
          {formatTime(callDuration)}
        </span>

        {/* Avatar */}
        <div className="relative mb-4">
          <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-emerald-500 shadow-xl">
            <img src={callerAvatar} alt={callerName} className="w-full h-full object-cover" />
          </div>
          <span className="absolute bottom-0 right-0 w-6 h-6 rounded-full bg-emerald-500 border-2 border-slate-900 flex items-center justify-center">
            <Phone className="w-3 h-3 text-white" />
          </span>
        </div>

        <h3 className="text-lg font-bold text-white mb-0.5">{callerName}</h3>
        <p className="text-xs text-slate-400 mb-8">{callerRole}</p>

        {/* Call In-progress sound wave visualization */}
        <div className="flex items-center gap-1.5 h-8 mb-8">
          {[12, 24, 32, 18, 28, 14, 22, 30, 16].map((h, i) => (
            <div
              key={i}
              className="w-1 bg-emerald-400/80 rounded-full animate-pulse"
              style={{
                height: `${h}px`,
                animationDelay: `${i * 120}ms`,
                animationDuration: '900ms'
              }}
            ></div>
          ))}
        </div>

        {/* Call Controls */}
        <div className="grid grid-cols-3 gap-4 w-full mb-8">
          <button
            onClick={() => setIsMuted(!isMuted)}
            className={`flex flex-col items-center justify-center p-3 rounded-2xl transition-all ${
              isMuted ? 'bg-white text-slate-900' : 'bg-slate-800/80 text-white hover:bg-slate-700'
            }`}
          >
            <Mic className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-medium">{isMuted ? 'Muted' : 'Mute'}</span>
          </button>

          <button
            onClick={() => setIsSpeaker(!isSpeaker)}
            className={`flex flex-col items-center justify-center p-3 rounded-2xl transition-all ${
              isSpeaker ? 'bg-emerald-600 text-white' : 'bg-slate-800/80 text-white hover:bg-slate-700'
            }`}
          >
            <Volume2 className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-medium">Speaker</span>
          </button>

          <button
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-800/80 text-white hover:bg-slate-700 transition-all"
          >
            <Grid className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-medium">Keypad</span>
          </button>
        </div>

        {/* End Call Button */}
        <button
          onClick={onClose}
          className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-700 active:scale-95 text-white flex items-center justify-center shadow-lg transition-transform"
          title="End Call"
        >
          <PhoneOff className="w-7 h-7" />
        </button>
      </div>
    </div>
  );
};

interface ChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  specialistName?: string;
  specialistAvatar?: string;
}

export const ChatModal: React.FC<ChatModalProps> = ({
  isOpen,
  onClose,
  specialistName = ASSIGNED_SPECIALIST.name,
  specialistAvatar = ASSIGNED_SPECIALIST.avatarUrl
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'specialist',
      text: 'Namaste! I have picked up the sterile injection and vacutainer kit. I am on my way to DLF Phase 5.',
      timestamp: '9:38 AM'
    },
    {
      id: 'm2',
      sender: 'specialist',
      text: 'Please have the doctor prescription ready for verification if applicable.',
      timestamp: '9:39 AM'
    }
  ]);
  const [inputVal, setInputVal] = useState('');

  if (!isOpen) return null;

  const handleSend = (textToSend?: string) => {
    const text = textToSend || inputVal.trim();
    if (!text) return;

    const newMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text,
      timestamp: 'Just now'
    };

    setMessages((prev) => [...prev, newMsg]);
    setInputVal('');

    // Simulate instant reply
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          sender: 'specialist',
          text: 'Understood! I will reach your door in about 10 minutes. Thank you.',
          timestamp: 'Just now'
        }
      ]);
    }, 1000);
  };

  const quickReplies = [
    'Yes, prescription is ready!',
    'Ring flat 402 bell directly',
    'Gate code is #108'
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="w-full max-w-sm h-[560px] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Chat Header */}
        <div className="bg-[#084d3e] text-white px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <img src={specialistAvatar} alt={specialistName} className="w-9 h-9 rounded-full object-cover border border-emerald-300" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 border border-[#084d3e] absolute bottom-0 right-0"></span>
            </div>
            <div>
              <h4 className="text-xs font-bold">{specialistName}</h4>
              <p className="text-[10px] text-emerald-200">Online • Care Specialist</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-full">
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2.5 bg-slate-50 text-left">
          <div className="text-center my-2">
            <span className="text-[9px] bg-slate-200/80 text-slate-600 px-2 py-0.5 rounded-full font-medium">
              Today • Booking #TX-2058-6718
            </span>
          </div>

          {messages.map((m) => {
            const isMe = m.sender === 'user';
            return (
              <div key={m.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                <div
                  className={`max-w-[80%] rounded-2xl px-3 py-2 text-xs leading-relaxed ${
                    isMe
                      ? 'bg-[#084d3e] text-white rounded-tr-xs'
                      : 'bg-white text-slate-800 border border-slate-200 shadow-2xs rounded-tl-xs'
                  }`}
                >
                  <p>{m.text}</p>
                </div>
                <span className="text-[8.5px] text-slate-400 mt-0.5 px-1">{m.timestamp}</span>
              </div>
            );
          })}
        </div>

        {/* Quick replies */}
        <div className="px-3 py-1.5 bg-white border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {quickReplies.map((qr) => (
            <button
              key={qr}
              onClick={() => handleSend(qr)}
              className="text-[10px] whitespace-nowrap bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-medium px-2 py-1 rounded-full border border-emerald-200"
            >
              {qr}
            </button>
          ))}
        </div>

        {/* Chat input */}
        <div className="p-2.5 bg-white border-t border-slate-200 flex items-center gap-2">
          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type a message to specialist..."
            className="flex-1 bg-slate-100 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-emerald-700"
          />
          <button
            onClick={() => handleSend()}
            disabled={!inputVal.trim()}
            className="w-8 h-8 rounded-xl bg-[#084d3e] disabled:opacity-40 text-white flex items-center justify-center shadow-xs"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

interface SpecialistDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCall: () => void;
  onChat: () => void;
}

export const SpecialistDetailsModal: React.FC<SpecialistDetailsModalProps> = ({
  isOpen,
  onClose,
  onCall,
  onChat
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl p-5 flex flex-col text-left border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 className="text-sm font-bold text-slate-900">Specialist Profile</h3>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 rounded-full">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="py-4 flex items-center gap-3">
          <img
            src={ASSIGNED_SPECIALIST.avatarUrl}
            alt={ASSIGNED_SPECIALIST.name}
            className="w-16 h-16 rounded-full object-cover border-2 border-emerald-500 shadow-md"
          />
          <div>
            <h4 className="text-base font-bold text-slate-900">{ASSIGNED_SPECIALIST.name}</h4>
            <p className="text-xs text-slate-500 font-medium">Certified Registered Nurse (RN)</p>
            <div className="flex items-center gap-1.5 mt-1 text-xs">
              <span className="flex items-center gap-0.5 font-bold text-amber-600">
                <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                <span>{ASSIGNED_SPECIALIST.rating}</span>
              </span>
              <span className="text-slate-400">({ASSIGNED_SPECIALIST.reviewCount} reviews)</span>
            </div>
          </div>
        </div>

        {/* Verification badges */}
        <div className="space-y-2 py-2 border-y border-slate-100 text-xs">
          <div className="flex items-center gap-2 text-slate-700">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Government Verified Nurse License • ID #RN-48201</span>
          </div>
          <div className="flex items-center gap-2 text-slate-700">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Fully Vaccinated & Certified in Infection Control</span>
          </div>
          <div className="flex items-center gap-2 text-slate-700">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>5+ Years Experience with Apollo & Fortis Clinics</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 mt-4">
          <button
            onClick={() => {
              onClose();
              onCall();
            }}
            className="py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5"
          >
            <Phone className="w-3.5 h-3.5" />
            <span>Voice Call</span>
          </button>
          <button
            onClick={() => {
              onClose();
              onChat();
            }}
            className="py-2.5 bg-[#084d3e] hover:bg-[#063f33] text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send Message</span>
          </button>
        </div>
      </div>
    </div>
  );
};

interface AddressModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedAddress: string;
  onSelectAddress: (addr: string) => void;
}

export const AddressModal: React.FC<AddressModalProps> = ({
  isOpen,
  onClose,
  selectedAddress,
  onSelectAddress
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl p-5 flex flex-col text-left border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 className="text-sm font-bold text-slate-900">Choose Delivery Address</h3>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 rounded-full">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-2 py-3">
          {ADDRESSES.map((addr) => {
            const isSelected = selectedAddress === addr.address;
            return (
              <div
                key={addr.id}
                onClick={() => {
                  onSelectAddress(addr.address);
                  onClose();
                }}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-900">{addr.label}</span>
                  {isSelected && <span className="text-[10px] font-bold text-emerald-700">Active</span>}
                </div>
                <p className="text-xs text-slate-600 mt-1">{addr.address}</p>
              </div>
            );
          })}
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-[#084d3e] text-white text-xs font-bold rounded-xl"
        >
          Confirm Location
        </button>
      </div>
    </div>
  );
};
