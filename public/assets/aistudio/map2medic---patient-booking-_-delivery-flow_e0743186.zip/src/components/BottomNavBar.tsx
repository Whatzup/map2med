import React from 'react';
import { Home, Calendar, ClipboardList, User } from 'lucide-react';

interface BottomNavBarProps {
  activeTab?: 'home' | 'book' | 'orders' | 'profile';
  onTabChange?: (tab: 'home' | 'book' | 'orders' | 'profile') => void;
  badgeCount?: number;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab = 'home',
  onTabChange,
  badgeCount = 0
}) => {
  interface TabItem {
    id: 'home' | 'book' | 'orders' | 'profile';
    label: string;
    icon: React.ElementType;
    badge?: number;
  }

  const tabs: TabItem[] = [
    { id: 'home', label: 'Home\n(Services)', icon: Home },
    { id: 'book', label: 'Book Visit', icon: Calendar },
    { id: 'orders', label: 'Orders', icon: ClipboardList, badge: badgeCount },
    { id: 'profile', label: 'My Profile', icon: User },
  ];

  return (
    <nav className="bg-white border-t border-slate-200 px-3 py-1.5 flex items-center justify-around select-none shrink-0 shadow-xs">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange?.(tab.id)}
            className={`flex flex-col items-center justify-center py-1 px-2 relative transition-all ${
              isActive ? 'text-emerald-800' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <div className="relative">
              <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px] text-emerald-800' : 'stroke-[1.75px]'}`} />
              {Boolean(tab.badge && tab.badge > 0) && (
                <span className="absolute -top-1 -right-2 bg-emerald-600 text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                  {tab.badge}
                </span>
              )}
            </div>
            <span
              className={`text-[9.5px] mt-0.5 leading-tight text-center ${
                isActive ? 'font-bold text-emerald-800' : 'font-medium text-slate-500'
              }`}
            >
              {tab.label}
            </span>
            {isActive && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-800 mt-0.5"></span>
            )}
          </button>
        );
      })}
    </nav>
  );
};
