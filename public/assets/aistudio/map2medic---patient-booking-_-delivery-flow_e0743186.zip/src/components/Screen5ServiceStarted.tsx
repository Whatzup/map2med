import React, { useState } from 'react';
import { Stethoscope, CheckCircle2, Clock, Phone, MessageCircle, Star, ChevronRight, Check, Headphones, Award, Sparkles, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';
import { HeaderBar } from './HeaderBar';
import { BottomNavBar } from './BottomNavBar';
import {
  ServiceStartedHeroIllustration,
  InjectionsCategoryIcon,
  LabTestsCategoryIcon,
  PhysioCategoryIcon
} from './MedicalIllustrations';
import { ASSIGNED_SPECIALIST, INITIAL_SERVICE_PROGRESS } from '../data/mockData';
import { ServiceProgressItem } from '../types';

interface Screen5ServiceStartedProps {
  onCallSpecialist?: () => void;
  onChatSpecialist?: () => void;
  onViewDetails?: () => void;
  onAddressClick?: () => void;
  onCallSupportClick?: () => void;
  onResetFlow?: () => void;
}

export const Screen5ServiceStarted: React.FC<Screen5ServiceStartedProps> = ({
  onCallSpecialist,
  onChatSpecialist,
  onViewDetails,
  onAddressClick,
  onCallSupportClick,
  onResetFlow
}) => {
  const [progressItems, setProgressItems] = useState<ServiceProgressItem[]>(INITIAL_SERVICE_PROGRESS);
  const [isCompleted, setIsCompleted] = useState(false);

  const renderServiceIcon = (category: string) => {
    switch (category) {
      case 'injections':
        return <InjectionsCategoryIcon size={26} />;
      case 'lab':
        return <LabTestsCategoryIcon size={26} />;
      case 'physio':
        return <PhysioCategoryIcon size={26} />;
      default:
        return <InjectionsCategoryIcon size={26} />;
    }
  };

  const trackerSteps = [
    { label: 'Confirmed', state: 'completed' },
    { label: 'Assigned', state: 'completed' },
    { label: 'On the way', state: 'completed' },
    { label: 'Arrived', state: 'completed' },
    { label: 'Service Started', state: 'current' },
  ];

  const handleToggleProgress = (id: string) => {
    setProgressItems((prev) => {
      const updated = prev.map((item) => {
        if (item.id === id) {
          if (item.status === 'in_progress') return { ...item, status: 'completed' as const };
          if (item.status === 'pending') return { ...item, status: 'in_progress' as const };
          return { ...item, status: 'pending' as const };
        }
        return item;
      });

      // Check if all are completed
      const allDone = updated.every((i) => i.status === 'completed');
      if (allDone && !isCompleted) {
        setIsCompleted(true);
        confetti({
          particleCount: 80,
          spread: 60,
          origin: { y: 0.6 }
        });
      }
      return updated;
    });
  };

  const handleCompleteAll = () => {
    setProgressItems((prev) =>
      prev.map((i) => ({ ...i, status: 'completed' as const }))
    );
    setIsCompleted(true);
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  return (
    <div className="flex-1 flex flex-col bg-[#f8faf9] text-slate-800 text-left">
      {/* Top Header */}
      <HeaderBar onAddressClick={onAddressClick} onCallSupportClick={onCallSupportClick} />

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-3.5 py-3 space-y-3.5 scrollbar-thin">
        {/* Hero Card: Service Started */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#064e3b] via-[#065f46] to-[#047857] text-white p-4 shadow-lg border border-emerald-800">
          <div className="relative z-10 pr-24">
            <div className="inline-flex items-center gap-1.5 bg-emerald-900/60 backdrop-blur-xs px-2.5 py-1 rounded-full border border-emerald-400/40 text-[10px] font-bold text-emerald-100 mb-2">
              <Stethoscope className="w-3.5 h-3.5 text-emerald-300" />
              <span>Service Started</span>
            </div>

            <h2 className="text-base font-extrabold tracking-tight">Care Underway</h2>

            <p className="text-[10.5px] text-emerald-100 font-medium leading-relaxed mt-1">
              Our care specialist has arrived and started the service.
            </p>

            <div className="mt-2.5 flex items-center gap-1 text-[9.5px] text-emerald-200 bg-emerald-900/40 px-2 py-0.5 rounded-md inline-flex border border-emerald-700/50">
              <Clock className="w-3 h-3" />
              <span>Session timer: 14 mins elapsed</span>
            </div>
          </div>

          {/* Service in action illustration */}
          <div className="absolute -right-2 -bottom-2 pointer-events-none transform scale-90 origin-bottom-right">
            <ServiceStartedHeroIllustration size={115} />
          </div>
        </div>

        {/* 5-Step Status Tracker */}
        <div className="bg-white rounded-xl p-3 border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between relative">
            <div className="absolute top-3 left-4 right-4 h-0.5 bg-emerald-600 -z-0"></div>

            {trackerSteps.map((step) => (
              <div key={step.label} className="flex flex-col items-center z-10">
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold transition-all ${
                    step.state === 'current'
                      ? 'bg-emerald-600 text-white ring-4 ring-emerald-100 shadow-sm animate-pulse'
                      : 'bg-emerald-600 text-white shadow-xs'
                  }`}
                >
                  {step.state === 'current' ? (
                    <Stethoscope className="w-3.5 h-3.5 text-white" />
                  ) : (
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  )}
                </div>
                <span className="text-[8.5px] mt-1 text-center font-bold text-emerald-800">
                  {step.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Assigned Care Specialist Card */}
        <div className="bg-white rounded-xl p-3 border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-slate-100">
            <span className="text-[11px] font-bold text-slate-900">Assigned Care Specialist</span>
            <button
              onClick={onViewDetails}
              className="text-[10px] font-bold text-emerald-800 hover:underline flex items-center gap-0.5"
            >
              <span>View details</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          </div>

          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <img
                  src={ASSIGNED_SPECIALIST.avatarUrl}
                  alt={ASSIGNED_SPECIALIST.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-emerald-500 shadow-xs"
                />
                <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white"></span>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-900 leading-tight">
                  {ASSIGNED_SPECIALIST.name}
                </h4>
                <p className="text-[9.5px] text-slate-500 font-medium">Care Specialist • RN</p>
                <div className="flex items-center gap-2 mt-0.5 text-[9.5px]">
                  <span className="flex items-center gap-0.5 font-bold text-amber-600">
                    <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                    <span>{ASSIGNED_SPECIALIST.rating}</span>
                  </span>
                  <span className="text-slate-400">({ASSIGNED_SPECIALIST.reviewCount})</span>
                  <span className="text-slate-400">•</span>
                  <span className="text-slate-600 font-medium">Exp: {ASSIGNED_SPECIALIST.experience}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={onCallSpecialist}
                className="w-8 h-8 rounded-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 flex flex-col items-center justify-center transition-all shadow-2xs active:scale-95"
                title="Call Amit Kumar"
              >
                <Phone className="w-3.5 h-3.5" />
                <span className="text-[7.5px] font-bold mt-0.2">Call</span>
              </button>

              <button
                onClick={onChatSpecialist}
                className="w-8 h-8 rounded-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 flex flex-col items-center justify-center transition-all shadow-2xs active:scale-95"
                title="Chat with Amit Kumar"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span className="text-[7.5px] font-bold mt-0.2">Chat</span>
              </button>
            </div>
          </div>
        </div>

        {/* Service Progress Checklist Card */}
        <div className="bg-white rounded-xl p-3 border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-900">Service Progress</span>
            <span className="text-[9.5px] text-slate-400 font-medium">Tap to simulate progress</span>
          </div>

          <div className="space-y-2">
            {progressItems.map((item) => {
              const isInProgress = item.status === 'in_progress';
              const isDone = item.status === 'completed';

              return (
                <div
                  key={item.id}
                  onClick={() => handleToggleProgress(item.id)}
                  className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between gap-2 ${
                    isDone
                      ? 'bg-emerald-50/60 border-emerald-200 text-slate-800'
                      : isInProgress
                      ? 'bg-white border-emerald-300 shadow-2xs ring-1 ring-emerald-200/50'
                      : 'bg-slate-50/70 border-slate-200 text-slate-600'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 transition-colors ${
                        isDone
                          ? 'bg-emerald-600 text-white'
                          : isInProgress
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-400'
                          : 'bg-white border border-slate-300 text-transparent'
                      }`}
                    >
                      {isDone && <Check className="w-3 h-3 stroke-[3]" />}
                      {isInProgress && <RefreshCw className="w-2.5 h-2.5 animate-spin text-emerald-700" />}
                    </div>

                    <div className="shrink-0 drop-shadow-2xs">
                      {renderServiceIcon(item.category)}
                    </div>

                    <div>
                      <h5 className="text-[11px] font-bold text-slate-900 leading-tight">
                        {item.title}
                      </h5>
                      <p className="text-[8.5px] text-slate-400 font-medium mt-0.5">
                        {item.timeEstimate}
                      </p>
                    </div>
                  </div>

                  <div>
                    {isInProgress && (
                      <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 text-[9px] font-bold px-2 py-0.5 rounded-full border border-emerald-200">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                        <span>In Progress</span>
                      </span>
                    )}
                    {isDone && (
                      <span className="inline-flex items-center gap-1 bg-teal-100 text-teal-800 text-[9px] font-bold px-2 py-0.5 rounded-full">
                        <span>Completed ✓</span>
                      </span>
                    )}
                    {item.status === 'pending' && (
                      <span className="text-[9px] font-semibold text-slate-400 px-2 py-0.5">
                        Pending
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {!isCompleted ? (
            <button
              onClick={handleCompleteAll}
              className="w-full mt-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 text-[10.5px] font-bold rounded-lg transition-colors"
            >
              Mark All as Completed
            </button>
          ) : (
            <div className="mt-2.5 bg-emerald-50 border border-emerald-300 rounded-lg p-2 text-center text-emerald-900 text-xs font-bold flex items-center justify-center gap-1.5">
              <Award className="w-4 h-4 text-emerald-700" />
              <span>All 3 Services Successfully Delivered!</span>
            </div>
          )}
        </div>

        {/* Support Card: "We're here for you" */}
        <div className="bg-white rounded-xl p-3 border border-slate-200/80 shadow-2xs flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-100 flex items-center justify-center shrink-0">
              <Headphones className="w-5 h-5 text-emerald-700" />
            </div>
            <div>
              <h5 className="text-[11px] font-bold text-slate-900 leading-tight">
                We're here for you
              </h5>
              <p className="text-[9.5px] text-slate-500 font-medium leading-tight mt-0.5">
                For any help, contact our support team.
              </p>
            </div>
          </div>

          <button
            onClick={onCallSupportClick}
            className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-900 text-[9.5px] font-bold rounded-lg shrink-0 flex items-center gap-1 transition-all active:scale-95 shadow-2xs"
          >
            <Phone className="w-3 h-3 text-emerald-700" />
            <span>1-800-MAP2MEDIC</span>
          </button>
        </div>

        {/* Reset / restart flow simulation button */}
        {onResetFlow && (
          <button
            onClick={onResetFlow}
            className="w-full text-slate-500 hover:text-emerald-800 text-[11px] font-semibold py-1.5 transition-colors"
          >
            ↺ Restart Delivery Flow Demo
          </button>
        )}
      </div>

      {/* Bottom Nav */}
      <BottomNavBar activeTab="orders" />
    </div>
  );
};
