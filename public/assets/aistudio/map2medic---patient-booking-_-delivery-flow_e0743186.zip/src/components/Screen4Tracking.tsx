import React, { useState } from 'react';
import { Bike, Phone, MessageCircle, Star, ChevronRight, Check, Clock, Home, AlertCircle, ArrowRight } from 'lucide-react';
import { HeaderBar } from './HeaderBar';
import { BottomNavBar } from './BottomNavBar';
import { ScooterSpecialistIllustration, InjectionProcedureIllustration, BloodSampleIllustration, PhysioIllustration } from './MedicalIllustrations';
import { LiveLocationMap } from './LiveLocationMap';
import { ASSIGNED_SPECIALIST } from '../data/mockData';

interface Screen4TrackingProps {
  onCallSpecialist?: () => void;
  onChatSpecialist?: () => void;
  onViewDetails?: () => void;
  onManageBooking?: () => void;
  onSpecialistArrived?: () => void;
  onAddressClick?: () => void;
  onCallSupportClick?: () => void;
}

export const Screen4Tracking: React.FC<Screen4TrackingProps> = ({
  onCallSpecialist,
  onChatSpecialist,
  onViewDetails,
  onManageBooking,
  onSpecialistArrived,
  onAddressClick,
  onCallSupportClick
}) => {
  const [eta] = useState(18);

  const trackerSteps = [
    { label: 'Confirmed', state: 'completed' },
    { label: 'Assigned', state: 'completed' },
    { label: 'On the way', state: 'current' },
    { label: 'Arriving', state: 'upcoming' },
    { label: 'Service Started', state: 'upcoming' },
  ];

  return (
    <div className="flex-1 flex flex-col bg-[#f8faf9] text-slate-800 text-left">
      {/* Top Header */}
      <HeaderBar onAddressClick={onAddressClick} onCallSupportClick={onCallSupportClick} />

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-3.5 py-3 space-y-3.5 scrollbar-thin">
        {/* Hero Card: On the way & ETA */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#064e3b] via-[#065f46] to-[#047857] text-white p-4 shadow-lg border border-emerald-800">
          <div className="relative z-10 pr-28">
            <div className="inline-flex items-center gap-1.5 bg-emerald-900/60 backdrop-blur-xs px-2.5 py-1 rounded-full border border-emerald-400/40 text-[10px] font-bold text-emerald-100 mb-2">
              <Bike className="w-3.5 h-3.5 text-emerald-300" />
              <span>On the way</span>
            </div>

            <p className="text-[11px] text-emerald-100 font-medium leading-snug">
              Your care specialist is on the way to you
            </p>

            <div className="mt-2.5">
              <span className="text-[10px] text-emerald-200/90 uppercase tracking-wider font-semibold block">
                ETA
              </span>
              <span className="text-2xl font-black text-white tracking-tight">
                {eta} mins
              </span>
            </div>
          </div>

          {/* 3D Scooter Specialist Illustration */}
          <div className="absolute -right-2 bottom-0 pointer-events-none transform scale-95 origin-bottom-right">
            <ScooterSpecialistIllustration size={135} />
          </div>
        </div>

        {/* 5-Step Status Tracker */}
        <div className="bg-white rounded-xl p-3 border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between relative">
            <div className="absolute top-3 left-4 right-4 h-0.5 bg-slate-200 -z-0"></div>
            <div className="absolute top-3 left-4 w-1/2 h-0.5 bg-emerald-600 -z-0"></div>

            {trackerSteps.map((step, idx) => (
              <div key={step.label} className="flex flex-col items-center z-10">
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold transition-all ${
                    step.state === 'completed'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : step.state === 'current'
                      ? 'bg-emerald-600 text-white ring-4 ring-emerald-100 shadow-sm'
                      : 'bg-white text-slate-400 border border-slate-300'
                  }`}
                >
                  {step.state === 'completed' ? (
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  ) : step.state === 'current' ? (
                    <Bike className="w-3.5 h-3.5 text-white" />
                  ) : (
                    <span>{idx + 1}</span>
                  )}
                </div>
                <span
                  className={`text-[8.5px] mt-1 text-center font-medium ${
                    step.state === 'current'
                      ? 'font-bold text-emerald-800'
                      : step.state === 'completed'
                      ? 'text-slate-700 font-semibold'
                      : 'text-slate-400'
                  }`}
                >
                  {step.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Assigned Care Specialist Card */}
        <div className="bg-white rounded-xl p-3 border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-slate-100">
            <span className="text-[11px] font-bold text-slate-900">Assigned Care Specialist</span>
            <button
              onClick={onViewDetails}
              className="text-[10px] font-bold text-emerald-800 hover:underline flex items-center gap-0.5"
            >
              <span>View details</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          </div>

          <div className="flex items-center justify-between gap-3">
            {/* Left: Avatar & Info */}
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <img
                  src={ASSIGNED_SPECIALIST.avatarUrl}
                  alt={ASSIGNED_SPECIALIST.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-emerald-500 shadow-xs"
                />
                <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white"></span>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-900 leading-tight">
                  {ASSIGNED_SPECIALIST.name}
                </h4>
                <p className="text-[9.5px] text-slate-500 font-medium">Care Specialist • RN</p>
                <div className="flex items-center gap-2 mt-0.5 text-[9.5px]">
                  <span className="flex items-center gap-0.5 font-bold text-amber-600">
                    <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                    <span>{ASSIGNED_SPECIALIST.rating}</span>
                  </span>
                  <span className="text-slate-400">({ASSIGNED_SPECIALIST.reviewCount})</span>
                  <span className="text-slate-400">•</span>
                  <span className="text-slate-600 font-medium">Exp: {ASSIGNED_SPECIALIST.experience}</span>
                </div>
              </div>
            </div>

            {/* Right: Call & Chat quick actions */}
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={onCallSpecialist}
                className="w-8 h-8 rounded-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 flex flex-col items-center justify-center transition-all shadow-2xs active:scale-95"
                title="Call Amit Kumar"
              >
                <Phone className="w-3.5 h-3.5" />
                <span className="text-[7.5px] font-bold mt-0.2">Call</span>
              </button>

              <button
                onClick={onChatSpecialist}
                className="w-8 h-8 rounded-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 flex flex-col items-center justify-center transition-all shadow-2xs active:scale-95"
                title="Chat with Amit Kumar"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span className="text-[7.5px] font-bold mt-0.2">Chat</span>
              </button>
            </div>
          </div>
        </div>

        {/* Services in this booking (3) */}
        <div className="bg-white rounded-xl p-3 border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-900">Services in this booking (3)</span>
            <button className="text-[10px] font-bold text-emerald-800 hover:underline">
              View all &gt;
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="bg-slate-50 hover:bg-emerald-50/50 border border-slate-200/80 rounded-xl p-2 text-center transition-colors">
              <div className="h-12 flex items-center justify-center overflow-hidden mb-1.5 drop-shadow-2xs">
                <InjectionProcedureIllustration size={44} />
              </div>
              <p className="text-[9px] font-bold text-slate-900 leading-tight truncate">Injection Admin</p>
              <span className="text-[8px] text-emerald-800 font-bold bg-emerald-100/80 px-1.5 py-0.2 rounded-full inline-block mt-0.5">At Home</span>
            </div>

            <div className="bg-slate-50 hover:bg-emerald-50/50 border border-slate-200/80 rounded-xl p-2 text-center transition-colors">
              <div className="h-12 flex items-center justify-center overflow-hidden mb-1.5 drop-shadow-2xs">
                <BloodSampleIllustration size={44} />
              </div>
              <p className="text-[9px] font-bold text-slate-900 leading-tight truncate">Lab Test (Blood)</p>
              <span className="text-[8px] text-rose-800 font-bold bg-rose-100/80 px-1.5 py-0.2 rounded-full inline-block mt-0.5">Basic Panel</span>
            </div>

            <div className="bg-slate-50 hover:bg-emerald-50/50 border border-slate-200/80 rounded-xl p-2 text-center transition-colors">
              <div className="h-12 flex items-center justify-center overflow-hidden mb-1.5 drop-shadow-2xs">
                <PhysioIllustration size={44} />
              </div>
              <p className="text-[9px] font-bold text-slate-900 leading-tight truncate">Physio Session</p>
              <span className="text-[8px] text-teal-800 font-bold bg-teal-100/80 px-1.5 py-0.2 rounded-full inline-block mt-0.5">45 Mins</span>
            </div>
          </div>
        </div>

        {/* Live Location Map */}
        <div className="bg-white rounded-xl p-3 border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-900">Live Location</span>
            <span className="text-[9px] text-slate-400 font-medium">Updated 2 min ago</span>
          </div>

          <LiveLocationMap isMoving={true} />
        </div>

        {/* Reschedule / Manage Link */}
        <div className="flex items-center justify-between px-1 text-[10.5px]">
          <span className="text-slate-500 font-medium">Need to reschedule or cancel?</span>
          <button
            onClick={onManageBooking}
            className="font-bold text-emerald-800 hover:underline flex items-center gap-0.5"
          >
            <span>Manage Booking</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        {/* Proceed to Service Started Simulation button */}
        <button
          onClick={onSpecialistArrived}
          className="w-full bg-[#084d3e] hover:bg-[#063f33] text-white text-xs font-bold py-2.5 px-4 rounded-xl shadow-sm flex items-center justify-center gap-2 transition-all active:scale-[0.99]"
        >
          <span>Specialist Arrived • Start Service</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Bottom Nav */}
      <BottomNavBar activeTab="orders" />
    </div>
  );
};
