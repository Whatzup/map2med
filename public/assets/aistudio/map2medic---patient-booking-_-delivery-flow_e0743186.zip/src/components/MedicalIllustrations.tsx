import React from 'react';

// ============================================================================
// 1. WHAT DO YOU NEED TODAY? CATEGORY ICONS (Crisp, High-Clarity, Instant Recognition)
// ============================================================================

// Injections Category Icon
export const InjectionsCategoryIcon: React.FC<{ size?: number; className?: string }> = ({ size = 36, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="injBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#d1fae5" />
        <stop offset="100%" stopColor="#a7f3d0" />
      </linearGradient>
      <linearGradient id="injLiquid" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#10b981" />
        <stop offset="100%" stopColor="#059669" />
      </linearGradient>
    </defs>
    <rect width="48" height="48" rx="12" fill="url(#injBg)" />
    {/* Syringe barrel rotated 45 deg */}
    <g transform="translate(24, 24) rotate(-45) translate(-24, -24)">
      {/* Plunger */}
      <rect x="22.5" y="4" width="3" height="10" rx="1.5" fill="#475569" />
      <path d="M19 4 H29" stroke="#334155" strokeWidth="2.5" strokeLinecap="round" />
      {/* Rubber stopper */}
      <rect x="21" y="14" width="6" height="3" rx="1" fill="#1e293b" />
      {/* Barrel */}
      <rect x="20" y="16" width="8" height="18" rx="2" fill="#ffffff" stroke="#047857" strokeWidth="1.75" />
      {/* Liquid inside */}
      <rect x="21.5" y="21" width="5" height="12" rx="1" fill="url(#injLiquid)" />
      {/* Measurement ticks */}
      <line x1="26" y1="23" x2="27.5" y2="23" stroke="#064e3b" strokeWidth="1.2" />
      <line x1="25.5" y1="26" x2="27.5" y2="26" stroke="#064e3b" strokeWidth="1.2" />
      <line x1="26" y1="29" x2="27.5" y2="29" stroke="#064e3b" strokeWidth="1.2" />
      {/* Needle hub & steel needle */}
      <path d="M22 34 L26 34 L25 37 L23 37 Z" fill="#94a3b8" />
      <line x1="24" y1="37" x2="24" y2="44" stroke="#64748b" strokeWidth="1.5" strokeLinecap="round" />
      {/* Drop at needle tip */}
      <circle cx="24" cy="46" r="1.5" fill="#10b981" />
    </g>
  </svg>
);

// Wound Care Category Icon
export const WoundCareCategoryIcon: React.FC<{ size?: number; className?: string }> = ({ size = 36, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="woundBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fef3c7" />
        <stop offset="100%" stopColor="#fde68a" />
      </linearGradient>
      <linearGradient id="bandGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fed7aa" />
        <stop offset="100%" stopColor="#fdba74" />
      </linearGradient>
    </defs>
    <rect width="48" height="48" rx="12" fill="url(#woundBg)" />
    
    {/* Crossed Adhesive Bandages */}
    <g transform="translate(24, 24) rotate(45) translate(-24, -24)">
      <rect x="14" y="20" width="20" height="8" rx="4" fill="url(#bandGrad)" stroke="#ea580c" strokeWidth="1.2" />
      <rect x="21" y="20" width="6" height="8" fill="#ffedd5" stroke="#ea580c" strokeWidth="0.8" />
      {/* Holes on bandage */}
      <circle cx="17" cy="24" r="0.8" fill="#c2410c" />
      <circle cx="31" cy="24" r="0.8" fill="#c2410c" />
    </g>

    <g transform="translate(24, 24) rotate(-45) translate(-24, -24)">
      <rect x="14" y="20" width="20" height="8" rx="4" fill="url(#bandGrad)" stroke="#ea580c" strokeWidth="1.2" />
      <rect x="21" y="20" width="6" height="8" fill="#ffffff" stroke="#ea580c" strokeWidth="0.8" />
      <circle cx="17" cy="24" r="0.8" fill="#c2410c" />
      <circle cx="31" cy="24" r="0.8" fill="#c2410c" />
    </g>

    {/* Medical red cross in center */}
    <path d="M24 21 V27 M21 24 H27" stroke="#dc2626" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

// Vitals Category Icon (BP Monitor + Heart pulse)
export const VitalsCategoryIcon: React.FC<{ size?: number; className?: string }> = ({ size = 36, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="vitalsBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#dbeafe" />
        <stop offset="100%" stopColor="#bfdbfe" />
      </linearGradient>
      <linearGradient id="screenGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#0f172a" />
        <stop offset="100%" stopColor="#1e293b" />
      </linearGradient>
    </defs>
    <rect width="48" height="48" rx="12" fill="url(#vitalsBg)" />

    {/* Digital Monitor Body */}
    <rect x="12" y="11" width="24" height="26" rx="4" fill="#ffffff" stroke="#2563eb" strokeWidth="1.5" />
    {/* Screen */}
    <rect x="15" y="14" width="18" height="13" rx="2" fill="url(#screenGrad)" />
    {/* Heartbeat pulse wave on screen */}
    <path d="M17 20.5 H19 L20.5 17 L22.5 24 L24 19 L25 22 L26.5 20.5 H31" stroke="#22c55e" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
    
    {/* Numeric readout indication */}
    <text x="16" y="26" fill="#93c5fd" fontSize="4.5" fontWeight="bold" fontFamily="monospace">120/80</text>

    {/* Button on device */}
    <circle cx="24" cy="32" r="2.5" fill="#2563eb" />
    <circle cx="24" cy="32" r="1" fill="#ffffff" />

    {/* Attached arm cuff outline */}
    <path d="M36 28 C40 28 41 33 41 37" stroke="#3b82f6" strokeWidth="1.5" strokeLinecap="round" strokeDasharray="2 2" fill="none" />
  </svg>
);

// Lab Tests Category Icon (Test tubes with sample fluids)
export const LabTestsCategoryIcon: React.FC<{ size?: number; className?: string }> = ({ size = 36, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="labBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#cffafe" />
        <stop offset="100%" stopColor="#a5f3fc" />
      </linearGradient>
    </defs>
    <rect width="48" height="48" rx="12" fill="url(#labBg)" />

    {/* Test tube 1 (Blood sample - Red) */}
    <g transform="translate(13, 10)">
      {/* Cap */}
      <rect x="0" y="0" width="8" height="3" rx="1" fill="#be123c" />
      {/* Glass */}
      <path d="M1 3 V22 C1 24.5 3 26 4 26 C5 26 7 24.5 7 22 V3 Z" fill="#ffffff" stroke="#0891b2" strokeWidth="1.2" />
      {/* Red Blood Fluid */}
      <path d="M1.5 12 V22 C1.5 24 3 25 4 25 C5 24 6.5 24 6.5 22 V12 Z" fill="#e11d48" />
      {/* Meniscus & bubbles */}
      <ellipse cx="4" cy="12" rx="2.5" ry="0.8" fill="#fda4af" />
      <circle cx="3" cy="17" r="0.7" fill="#ffffff" opacity="0.6" />
    </g>

    {/* Test tube 2 (Reagent - Blue/Green) */}
    <g transform="translate(26, 12)">
      {/* Cap */}
      <rect x="0" y="0" width="8" height="3" rx="1" fill="#4338ca" />
      {/* Glass */}
      <path d="M1 3 V20 C1 22.5 3 24 4 24 C5 24 7 22.5 7 20 V3 Z" fill="#ffffff" stroke="#0891b2" strokeWidth="1.2" />
      {/* Fluid */}
      <path d="M1.5 10 V20 C1.5 22 3 23 4 23 C5 22 6.5 22 6.5 20 V10 Z" fill="#0284c7" />
      <ellipse cx="4" cy="10" rx="2.5" ry="0.8" fill="#7dd3fc" />
    </g>

    {/* Blood droplet */}
    <path d="M23 35 C23 33 25 30 25 30 C25 30 27 33 27 35 C27 36.5 26 38 25 38 C24 38 23 36.5 23 35 Z" fill="#e11d48" />
  </svg>
);

// Physio Category Icon (Active human articulation & healing stretch)
export const PhysioCategoryIcon: React.FC<{ size?: number; className?: string }> = ({ size = 36, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="physioBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ccfbf1" />
        <stop offset="100%" stopColor="#99f6e4" />
      </linearGradient>
    </defs>
    <rect width="48" height="48" rx="12" fill="url(#physioBg)" />

    {/* Mobility motion arc */}
    <path d="M12 28 C12 16 22 10 34 12" stroke="#0d9488" strokeWidth="2" strokeLinecap="round" strokeDasharray="3 3" opacity="0.6" fill="none" />
    
    {/* Human Figure in gentle therapy pose */}
    {/* Head */}
    <circle cx="24" cy="14" r="4.5" fill="#0f766e" />
    {/* Torso */}
    <path d="M24 19 L23 27" stroke="#0f766e" strokeWidth="3.5" strokeLinecap="round" />
    {/* Raised flexible arms */}
    <path d="M14 18 L24 21 L34 16" stroke="#0f766e" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" />
    {/* Legs in lunging / rehab pose */}
    <path d="M23 27 L18 36 M23 27 L29 36" stroke="#0f766e" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" />

    {/* Joint highlight points */}
    <circle cx="14" cy="18" r="1.5" fill="#f59e0b" />
    <circle cx="34" cy="16" r="1.5" fill="#f59e0b" />
    <circle cx="18" cy="36" r="1.5" fill="#10b981" />
    <circle cx="29" cy="36" r="1.5" fill="#10b981" />
  </svg>
);

// Elder Care Category Icon (Supportive Wheelchair & Caring Hands)
export const ElderCareCategoryIcon: React.FC<{ size?: number; className?: string }> = ({ size = 36, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="elderBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#e0e7ff" />
        <stop offset="100%" stopColor="#c7d2fe" />
      </linearGradient>
    </defs>
    <rect width="48" height="48" rx="12" fill="url(#elderBg)" />

    {/* Wheelchair big wheel */}
    <circle cx="23" cy="31" r="7.5" stroke="#4338ca" strokeWidth="2.2" fill="none" />
    <circle cx="23" cy="31" r="2" fill="#4338ca" />
    <circle cx="34" cy="36" r="2.5" fill="#4338ca" />

    {/* Wheelchair frame */}
    <path d="M17 19 H22 L24 29 H33" stroke="#4338ca" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
    <path d="M24 29 L34 36" stroke="#4338ca" strokeWidth="1.8" strokeLinecap="round" />

    {/* Senior Person seated */}
    <circle cx="22" cy="14" r="3.5" fill="#6366f1" />
    {/* Body / Arms */}
    <path d="M22 18 L24 25 L30 25" stroke="#6366f1" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

    {/* Love / Care Heart */}
    <path d="M34 14 C34 12 36 10 38 10 C40 10 41 12 41 13 C41 16 38 18 38 18 C38 18 35 16 35 13 Z" fill="#ef4444" />
  </svg>
);


// ============================================================================
// 2. DETAILED SERVICE CARDS & CART ILLUSTRATIVE SCENES (Crystal-clear procedures)
// ============================================================================

// 1. Injection Administration Scene (Nurse giving gentle arm injection)
export const InjectionProcedureIllustration: React.FC<{ size?: number; className?: string }> = ({ size = 70, className = '' }) => (
  <svg width={size} height={size * 0.9} viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="injCardBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ecfdf5" />
        <stop offset="100%" stopColor="#d1fae5" />
      </linearGradient>
    </defs>
    <rect width="120" height="100" rx="14" fill="url(#injCardBg)" />

    {/* Patient seated on left */}
    <g transform="translate(14, 20)">
      {/* Patient head */}
      <circle cx="22" cy="18" r="12" fill="#fcd34d" />
      {/* Dark styled hair */}
      <path d="M12 16 C12 8 20 6 28 8 C34 10 34 18 32 20 Z" fill="#1e293b" />
      {/* Face features */}
      <circle cx="25" cy="18" r="1.5" fill="#0f172a" />
      <path d="M24 23 Q27 25 30 23" stroke="#b45309" strokeWidth="1.5" strokeLinecap="round" fill="none" />
      
      {/* Torso & Patient Blue T-shirt */}
      <path d="M10 52 C10 36 16 32 34 32 C38 32 40 34 42 38 L42 56 Z" fill="#3b82f6" />
      {/* Patient arm resting */}
      <path d="M34 36 L48 46 L58 46" stroke="#fcd34d" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
    </g>

    {/* Nurse in scrubs on right administering injection */}
    <g transform="translate(56, 12)">
      {/* Nurse Head */}
      <circle cx="34" cy="18" r="12" fill="#fcd34d" />
      {/* Hair in neat bun */}
      <path d="M24 16 C24 6 36 6 44 10 C46 16 44 22 42 22 Z" fill="#0f172a" />
      <circle cx="22" cy="10" r="4.5" fill="#0f172a" />
      {/* Face Mask */}
      <rect x="25" y="18" width="12" height="8" rx="3" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1" />
      <circle cx="28" cy="15" r="1.3" fill="#0f172a" />

      {/* Scrub Body */}
      <path d="M18 64 C18 42 26 34 44 34 C58 34 62 42 62 64 Z" fill="#0f766e" />
      
      {/* Nurse Hands holding syringe */}
      <path d="M26 38 L10 46" stroke="#0f766e" strokeWidth="6" strokeLinecap="round" />
      <circle cx="8" cy="47" r="4" fill="#fcd34d" />

      {/* Sterile Syringe with green liquid and shiny needle */}
      <g transform="translate(-4, 40) rotate(-15)">
        <rect x="0" y="3" width="14" height="6" rx="1.5" fill="#ffffff" stroke="#047857" strokeWidth="1.2" />
        <rect x="2" y="4.5" width="8" height="3" fill="#10b981" />
        <line x1="14" y1="6" x2="22" y2="6" stroke="#475569" strokeWidth="1.5" strokeLinecap="round" />
        <rect x="-4" y="4" width="4" height="4" rx="1" fill="#475569" />
      </g>
    </g>

    {/* Cotton swab on patient's arm */}
    <ellipse cx="64" cy="67" rx="3.5" ry="2.5" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1" />

    {/* Service badge tag */}
    <g transform="translate(8, 8)">
      <rect width="42" height="15" rx="7.5" fill="#084d3e" />
      <text x="21" y="11" fill="#ffffff" fontSize="7.5" fontWeight="bold" textAnchor="middle">INJECTION</text>
    </g>
  </svg>
);

// 2. IV Drip Setup Procedure Illustration (Stainless pole, IV Saline Bag, Infusion Line)
export const IVDripProcedureIllustration: React.FC<{ size?: number; className?: string }> = ({ size = 70, className = '' }) => (
  <svg width={size} height={size * 0.9} viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="ivCardBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#f0fdfa" />
        <stop offset="100%" stopColor="#ccfbf1" />
      </linearGradient>
      <linearGradient id="salineGrad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#e0f2fe" />
        <stop offset="100%" stopColor="#bae6fd" />
      </linearGradient>
    </defs>
    <rect width="120" height="100" rx="14" fill="url(#ivCardBg)" />

    {/* IV Stand Pole */}
    <line x1="42" y1="12" x2="42" y2="88" stroke="#64748b" strokeWidth="3" strokeLinecap="round" />
    <path d="M34 16 C34 12 42 12 42 16 C42 12 50 12 50 16" stroke="#475569" strokeWidth="2.5" fill="none" />
    <line x1="28" y1="88" x2="56" y2="88" stroke="#475569" strokeWidth="3" strokeLinecap="round" />

    {/* 500ml Saline Solution Bag */}
    <g transform="translate(28, 18)">
      <rect x="0" y="0" width="20" height="30" rx="5" fill="url(#salineGrad)" stroke="#0284c7" strokeWidth="1.5" />
      {/* Hanging tab hole */}
      <circle cx="10" cy="4" r="2" fill="#ffffff" stroke="#0284c7" strokeWidth="1" />
      {/* Fluid measurement levels */}
      <line x1="4" y1="12" x2="8" y2="12" stroke="#0369a1" strokeWidth="1" />
      <line x1="4" y1="18" x2="8" y2="18" stroke="#0369a1" strokeWidth="1" />
      <line x1="4" y1="24" x2="8" y2="24" stroke="#0369a1" strokeWidth="1" />
      {/* Label: 0.9% NaCl */}
      <rect x="7" y="11" width="10" height="12" rx="1.5" fill="#ffffff" opacity="0.9" />
      <text x="12" y="19" fill="#0369a1" fontSize="4.5" fontWeight="bold" textAnchor="middle">NaCl</text>

      {/* Drip Chamber & Roller Clamp */}
      <rect x="7.5" y="30" width="5" height="10" rx="2" fill="#ffffff" stroke="#0284c7" strokeWidth="1.2" />
      <circle cx="10" cy="35" r="1.2" fill="#0284c7" />
    </g>

    {/* Flexible IV Infusion Line flowing across */}
    <path d="M38 58 Q48 70 66 65 T96 68" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" fill="none" />
    
    {/* Patient Arm with IV cannula & adhesive fixator */}
    <g transform="translate(68, 52)">
      <rect x="10" y="12" width="36" height="14" rx="7" fill="#fcd34d" />
      {/* Cannula wings & port */}
      <rect x="18" y="10" width="12" height="6" rx="2" fill="#3b82f6" />
      <rect x="22" y="7" width="4" height="4" rx="1" fill="#22c55e" />
      {/* Transparent sterile dressing over cannula */}
      <rect x="15" y="8" width="18" height="14" rx="3" fill="#ffffff" opacity="0.6" stroke="#93c5fd" strokeWidth="1" />
    </g>

    {/* Badge */}
    <g transform="translate(8, 8)">
      <rect width="36" height="15" rx="7.5" fill="#0369a1" />
      <text x="18" y="11" fill="#ffffff" fontSize="7.5" fontWeight="bold" textAnchor="middle">IV DRIP</text>
    </g>
  </svg>
);

// 3. Vaccination Procedure Illustration (Vial, Vaccine Shot & Certified Protection Shield)
export const VaccineProcedureIllustration: React.FC<{ size?: number; className?: string }> = ({ size = 70, className = '' }) => (
  <svg width={size} height={size * 0.9} viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="vacCardBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fffbeb" />
        <stop offset="100%" stopColor="#fef3c7" />
      </linearGradient>
      <linearGradient id="vialGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ffffff" />
        <stop offset="100%" stopColor="#e2e8f0" />
      </linearGradient>
    </defs>
    <rect width="120" height="100" rx="14" fill="url(#vacCardBg)" />

    {/* Protection Shield in background */}
    <g transform="translate(68, 16)">
      <path d="M22 6 L38 12 V24 C38 34 28 42 22 46 C16 42 6 34 6 24 V12 Z" fill="#dcfce7" stroke="#16a34a" strokeWidth="2" />
      <path d="M16 25 L20 29 L28 19" stroke="#15803d" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
    </g>

    {/* Glass Vaccine Vial on left */}
    <g transform="translate(20, 24)">
      {/* Aluminum / plastic crimp cap */}
      <rect x="5" y="0" width="14" height="4" rx="1.5" fill="#2563eb" />
      <rect x="7" y="4" width="10" height="3" fill="#94a3b8" />
      {/* Glass Bottle Body */}
      <rect x="2" y="7" width="20" height="32" rx="4" fill="url(#vialGrad)" stroke="#475569" strokeWidth="1.5" />
      {/* Vaccine Fluid */}
      <rect x="3.5" y="20" width="17" height="17.5" rx="2" fill="#60a5fa" opacity="0.85" />
      {/* Label with Cross */}
      <rect x="5" y="11" width="14" height="14" rx="2" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1" />
      <path d="M12 14 V22 M8 18 H16" stroke="#2563eb" strokeWidth="2" strokeLinecap="round" />
    </g>

    {/* Syringe withdrawing vaccine */}
    <g transform="translate(48, 20) rotate(35)">
      <rect x="0" y="6" width="26" height="8" rx="2" fill="#ffffff" stroke="#047857" strokeWidth="1.5" />
      <rect x="4" y="8" width="14" height="4" fill="#10b981" />
      <line x1="26" y1="10" x2="38" y2="10" stroke="#64748b" strokeWidth="1.8" strokeLinecap="round" />
      <rect x="-6" y="8" width="6" height="4" rx="1" fill="#475569" />
    </g>

    {/* Badge */}
    <g transform="translate(8, 8)">
      <rect width="44" height="15" rx="7.5" fill="#d97706" />
      <text x="22" y="11" fill="#ffffff" fontSize="7.5" fontWeight="bold" textAnchor="middle">VACCINE</text>
    </g>
  </svg>
);

// 4. IM / IV Injection Scene (Antibiotic & Specialized Dose)
export const IMIProcedureIllustration: React.FC<{ size?: number; className?: string }> = ({ size = 70, className = '' }) => (
  <svg width={size} height={size * 0.9} viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="imCardBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#f5f3ff" />
        <stop offset="100%" stopColor="#ede9fe" />
      </linearGradient>
    </defs>
    <rect width="120" height="100" rx="14" fill="url(#imCardBg)" />

    {/* Glass Ampoule & Syringe */}
    <g transform="translate(18, 24)">
      {/* Ampoule tip and neck */}
      <path d="M10 2 L12 8 H10 V14 H6 V8 H4 Z" fill="#cbd5e1" stroke="#6b21a8" strokeWidth="1" />
      <rect x="4" y="14" width="8" height="24" rx="3" fill="#ffffff" stroke="#6b21a8" strokeWidth="1.5" />
      <rect x="5.5" y="22" width="5" height="15" rx="1.5" fill="#a855f7" />
      {/* Blue snap ring on ampoule */}
      <circle cx="8" cy="11" r="1" fill="#2563eb" />
    </g>

    {/* Precision Calibrated Syringe */}
    <g transform="translate(42, 22) rotate(-25)">
      <rect x="0" y="8" width="34" height="10" rx="2.5" fill="#ffffff" stroke="#6b21a8" strokeWidth="1.7" />
      <rect x="6" y="10.5" width="18" height="5" fill="#9333ea" />
      {/* Ticks */}
      <line x1="8" y1="9" x2="8" y2="12" stroke="#4c1d95" strokeWidth="1.2" />
      <line x1="14" y1="9" x2="14" y2="12" stroke="#4c1d95" strokeWidth="1.2" />
      <line x1="20" y1="9" x2="20" y2="12" stroke="#4c1d95" strokeWidth="1.2" />
      
      {/* Needle */}
      <line x1="34" y1="13" x2="52" y2="13" stroke="#475569" strokeWidth="2" strokeLinecap="round" />
      {/* Plunger */}
      <rect x="-8" y="11" width="8" height="4" rx="1" fill="#334155" />
      <path d="M-8 8 V18" stroke="#334155" strokeWidth="2" strokeLinecap="round" />
    </g>

    {/* Sterile Blister Pill Pack on side */}
    <g transform="translate(72, 48)">
      <rect width="32" height="22" rx="3" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1" />
      <circle cx="9" cy="11" r="4.5" fill="#c084fc" />
      <circle cx="23" cy="11" r="4.5" fill="#c084fc" />
    </g>

    {/* Badge */}
    <g transform="translate(8, 8)">
      <rect width="42" height="15" rx="7.5" fill="#6b21a8" />
      <text x="21" y="11" fill="#ffffff" fontSize="7.5" fontWeight="bold" textAnchor="middle">IM / IV DOSE</text>
    </g>
  </svg>
);

// 5. Blood Test / Lab Sample Collection Scene (Phlebotomy Vacutainer Tubes & Butterfly Needle)
export const BloodSampleIllustration: React.FC<{ size?: number; className?: string }> = ({ size = 70, className = '' }) => (
  <svg width={size} height={size * 0.9} viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="bloodCardBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fff1f2" />
        <stop offset="100%" stopColor="#ffe4e6" />
      </linearGradient>
    </defs>
    <rect width="120" height="100" rx="14" fill="url(#bloodCardBg)" />

    {/* Rack with 2 Vacutainer Blood Collection Tubes */}
    <g transform="translate(20, 20)">
      {/* Tube 1: Lavender EDTA Tube */}
      <g transform="translate(0, 0)">
        <rect x="0" y="0" width="12" height="6" rx="2" fill="#7c3aed" />
        <path d="M2 6 V36 C2 40 4 42 6 42 C8 42 10 40 10 36 V6 Z" fill="#ffffff" stroke="#6d28d9" strokeWidth="1.3" />
        <path d="M3 18 V36 C3 39 4 41 6 41 C8 41 9 39 9 36 V18 Z" fill="#e11d48" />
        {/* Label */}
        <rect x="3" y="9" width="6" height="8" fill="#f5f3ff" />
      </g>

      {/* Tube 2: Red Serum Tube */}
      <g transform="translate(16, 2)">
        <rect x="0" y="0" width="12" height="6" rx="2" fill="#dc2626" />
        <path d="M2 6 V34 C2 38 4 40 6 40 C8 40 10 38 10 34 V6 Z" fill="#ffffff" stroke="#b91c1c" strokeWidth="1.3" />
        <path d="M3 16 V34 C3 37 4 39 6 39 C8 39 9 37 9 34 V16 Z" fill="#be123c" />
        <rect x="3" y="9" width="6" height="6" fill="#fef2f2" />
      </g>
    </g>

    {/* Butterfly Blood Collection Needle & Tubing */}
    <g transform="translate(58, 26)">
      {/* Blue Butterfly Wings */}
      <path d="M14 18 C14 12 8 8 2 12 C2 18 10 22 14 20 Z" fill="#0284c7" />
      <path d="M14 22 C14 28 8 32 2 28 C2 22 10 18 14 20 Z" fill="#0284c7" />
      <circle cx="14" cy="20" r="3" fill="#0369a1" />

      {/* Needle Tip */}
      <line x1="14" y1="20" x2="28" y2="20" stroke="#475569" strokeWidth="2" strokeLinecap="round" />

      {/* Flexible coiled tubing with red blood sample visible */}
      <path d="M14 20 Q-6 24 -2 38 T18 48 T36 44" stroke="#e11d48" strokeWidth="2.5" strokeLinecap="round" fill="none" />
    </g>

    {/* Diagnostic Droplet */}
    <g transform="translate(94, 60)">
      <path d="M8 0 C8 0 16 9 16 14 C16 18.5 12.5 22 8 22 C3.5 22 0 18.5 0 14 C0 9 8 0 8 0 Z" fill="#e11d48" />
      <circle cx="5.5" cy="13" r="2" fill="#ffffff" opacity="0.6" />
    </g>

    {/* Badge */}
    <g transform="translate(8, 8)">
      <rect width="44" height="15" rx="7.5" fill="#be123c" />
      <text x="22" y="11" fill="#ffffff" fontSize="7.5" fontWeight="bold" textAnchor="middle">BLOOD TEST</text>
    </g>
  </svg>
);

// 6. Physio Rehabilitation Session Scene (Certified therapist aiding movement)
export const PhysioIllustration: React.FC<{ size?: number; className?: string }> = ({ size = 70, className = '' }) => (
  <svg width={size} height={size * 0.9} viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="physioCardBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#f0fdfa" />
        <stop offset="100%" stopColor="#ccfbf1" />
      </linearGradient>
    </defs>
    <rect width="120" height="100" rx="14" fill="url(#physioCardBg)" />

    {/* Motion Guideline Arc */}
    <path d="M36 68 C46 42 66 38 88 46" stroke="#0d9488" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="3 3" fill="none" />

    {/* Senior Patient Seated on left */}
    <g transform="translate(18, 16)">
      {/* Head with gray hair */}
      <circle cx="20" cy="18" r="11" fill="#fcd34d" />
      <path d="M10 16 C10 8 20 6 28 8 C32 12 30 18 28 20 Z" fill="#94a3b8" />
      <circle cx="22" cy="18" r="1.5" fill="#0f172a" />
      {/* Patient Torso */}
      <path d="M8 56 C8 40 14 34 32 34 C38 34 42 42 42 56 Z" fill="#64748b" />
      {/* Patient Arm extended for therapy */}
      <path d="M30 40 L52 48" stroke="#fcd34d" strokeWidth="7" strokeLinecap="round" />
    </g>

    {/* Physiotherapist on right supporting arm/shoulder */}
    <g transform="translate(62, 14)">
      <circle cx="26" cy="18" r="11" fill="#fcd34d" />
      <path d="M16 16 C16 8 26 6 34 8 C36 12 36 18 34 20 Z" fill="#0f172a" />
      {/* Therapist Scrubs */}
      <path d="M12 60 C12 38 22 34 38 34 C48 34 52 42 52 60 Z" fill="#0d9488" />
      
      {/* Supportive hands guiding patient */}
      <path d="M18 42 L6 48" stroke="#0d9488" strokeWidth="6" strokeLinecap="round" />
      <circle cx="5" cy="49" r="4.5" fill="#fcd34d" />
      <path d="M12 50 L-4 50" stroke="#fcd34d" strokeWidth="4.5" strokeLinecap="round" />
    </g>

    {/* Therapy Dumbbell / Mobility ball on floor */}
    <g transform="translate(84, 72)">
      <circle cx="8" cy="8" r="8" fill="#14b8a6" />
      <circle cx="6" cy="6" r="2.5" fill="#ffffff" opacity="0.5" />
    </g>

    {/* Badge */}
    <g transform="translate(8, 8)">
      <rect width="38" height="15" rx="7.5" fill="#0f766e" />
      <text x="19" y="11" fill="#ffffff" fontSize="7.5" fontWeight="bold" textAnchor="middle">PHYSIO</text>
    </g>
  </svg>
);


// ============================================================================
// 3. HERO CARD 3D MEDICAL SPECIALISTS & DELIVERY VEHICLE
// ============================================================================

// Character with Stethoscope & Tablet (Screen 1 & 3 Hero)
export const NurseDoctorIllustration: React.FC<{ size?: number; className?: string }> = ({ size = 120, className = '' }) => (
  <svg width={size} height={size * 1.15} viewBox="0 0 140 160" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="scrubGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#0d9488" />
        <stop offset="100%" stopColor="#044e45" />
      </linearGradient>
      <linearGradient id="skinGrad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#fde047" />
        <stop offset="100%" stopColor="#f59e0b" />
      </linearGradient>
      <linearGradient id="stethGrad" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#94a3b8" />
        <stop offset="100%" stopColor="#f1f5f9" />
      </linearGradient>
    </defs>

    {/* Body / Medical Scrubs */}
    <path d="M28 160 C28 116 40 96 70 96 C100 96 112 116 112 160 Z" fill="url(#scrubGrad)" />
    
    {/* V-neck scrub collar */}
    <path d="M54 96 L70 118 L86 96 Z" fill="#fde047" />
    <path d="M50 96 L70 122 L90 96" stroke="#042f2e" strokeWidth="3" fill="none" strokeLinecap="round" />

    {/* Neck */}
    <rect x="62" y="76" width="16" height="26" rx="5" fill="url(#skinGrad)" />

    {/* Head */}
    <circle cx="70" cy="58" r="27" fill="url(#skinGrad)" />
    
    {/* Hair (Styled modern crop) */}
    <path d="M42 56 C42 34 52 26 70 26 C88 26 98 34 98 56 C94 44 86 40 70 40 C54 40 46 44 42 56 Z" fill="#1e293b" />
    <path d="M41 52 C40 42 48 32 60 30 C64 29 80 28 94 36 C98 42 98 50 98 52 C94 48 86 46 78 46 C66 46 52 48 41 52 Z" fill="#0f172a" />

    {/* Face details (Friendly, smiling, trustworthy) */}
    <circle cx="60" cy="58" r="3" fill="#0f172a" />
    <circle cx="80" cy="58" r="3" fill="#0f172a" />
    <circle cx="61.5" cy="56.5" r="1" fill="#ffffff" />
    <circle cx="81.5" cy="56.5" r="1" fill="#ffffff" />
    
    {/* Smile */}
    <path d="M61 68 Q70 76 79 68" stroke="#9a3412" strokeWidth="2.5" strokeLinecap="round" fill="none" />
    {/* Rosy Cheeks */}
    <circle cx="55" cy="64" r="4.5" fill="#f87171" opacity="0.45" />
    <circle cx="85" cy="64" r="4.5" fill="#f87171" opacity="0.45" />

    {/* Stethoscope around neck */}
    <path d="M50 92 Q46 122 62 136 Q70 144 78 136 Q94 122 90 92" stroke="url(#stethGrad)" strokeWidth="4" strokeLinecap="round" fill="none" />
    <circle cx="70" cy="144" r="8" fill="#e2e8f0" stroke="#475569" strokeWidth="2.5" />
    <circle cx="70" cy="144" r="3.5" fill="#0f766e" />

    {/* Digital Medical Tablet held in hand */}
    <g transform="translate(14, 88) rotate(-10)">
      <rect width="30" height="42" rx="4" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
      <rect x="3" y="4" width="24" height="34" rx="2" fill="#0284c7" />
      <line x1="6" y1="10" x2="18" y2="10" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
      <line x1="6" y1="16" x2="22" y2="16" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="6" y1="22" x2="16" y2="22" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" />
      {/* Checkmark on tablet screen */}
      <circle cx="18" cy="28" r="4.5" fill="#22c55e" />
      <path d="M16 28 L17.5 29.5 L20 27" stroke="#ffffff" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
    </g>

    {/* Thumbs up badge */}
    <g transform="translate(94, 95)">
      <circle cx="16" cy="16" r="14" fill="#059669" stroke="#ffffff" strokeWidth="2" />
      <path d="M12 16 L15 19 L21 13" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    </g>
  </svg>
);

// Scooter Specialist On The Way (Screen 4 Hero)
export const ScooterSpecialistIllustration: React.FC<{ size?: number; className?: string }> = ({ size = 150, className = '' }) => (
  <svg width={size} height={size * 0.82} viewBox="0 0 200 160" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="scooterBody" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#10b981" />
        <stop offset="100%" stopColor="#047857" />
      </linearGradient>
      <linearGradient id="boxGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#065f46" />
        <stop offset="100%" stopColor="#022c22" />
      </linearGradient>
    </defs>

    {/* Speed lines */}
    <path d="M15 130 L45 130" stroke="#6ee7b7" strokeWidth="3" strokeLinecap="round" strokeDasharray="4 6" />
    <path d="M25 142 L65 142" stroke="#6ee7b7" strokeWidth="2.5" strokeLinecap="round" />
    <path d="M10 115 L35 115" stroke="#6ee7b7" strokeWidth="2" strokeLinecap="round" />

    {/* Scooter Wheels */}
    <g transform="translate(48, 115)">
      <circle cx="16" cy="16" r="16" fill="#0f172a" />
      <circle cx="16" cy="16" r="10" fill="#94a3b8" />
      <circle cx="16" cy="16" r="4" fill="#047857" />
    </g>
    <g transform="translate(142, 115)">
      <circle cx="16" cy="16" r="16" fill="#0f172a" />
      <circle cx="16" cy="16" r="10" fill="#94a3b8" />
      <circle cx="16" cy="16" r="4" fill="#047857" />
    </g>

    {/* Scooter Chassis */}
    <path d="M58 128 L146 128 L138 100 L115 100 L100 120 L75 120 Z" fill="url(#scooterBody)" />
    <rect x="68" y="122" width="56" height="6" rx="3" fill="#0f172a" />
    
    {/* Handlebar & Headlight */}
    <path d="M142 118 L130 68 L142 66" stroke="#047857" strokeWidth="7" strokeLinecap="round" />
    <circle cx="145" cy="64" r="6" fill="#fef08a" />
    {/* Light beam */}
    <polygon points="148,64 195,50 195,78" fill="#fef08a" opacity="0.3" />

    {/* Delivery Care Box with Bold Medical Cross */}
    <rect x="40" y="66" width="40" height="40" rx="7" fill="url(#boxGrad)" stroke="#34d399" strokeWidth="2" />
    <path d="M60 76 V96 M50 86 H70" stroke="#ffffff" strokeWidth="4.5" strokeLinecap="round" />

    {/* Specialist Rider */}
    <path d="M84 72 C80 90 92 115 104 115 C116 115 124 100 120 72 Z" fill="#0d9488" />
    <path d="M96 72 L130 76" stroke="#0d9488" strokeWidth="8" strokeLinecap="round" />

    {/* Rider Helmet */}
    <circle cx="104" cy="52" r="14" fill="#fcd34d" />
    <path d="M92 48 C92 34 104 32 114 34 C122 36 124 45 120 54 L94 54 Z" fill="#047857" />
    <rect x="106" y="46" width="12" height="6" rx="2" fill="#0f172a" />
    <circle cx="100" cy="54" r="1.5" fill="#1e293b" />
  </svg>
);

// Service Started Scene (Screen 5 Hero)
export const ServiceStartedHeroIllustration: React.FC<{ size?: number; className?: string }> = ({ size = 130, className = '' }) => (
  <svg width={size} height={size * 0.9} viewBox="0 0 160 140" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="warmBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ecfdf5" />
        <stop offset="100%" stopColor="#d1fae5" />
      </linearGradient>
    </defs>
    <rect width="160" height="140" rx="16" fill="url(#warmBg)" />
    
    {/* Room Window */}
    <rect x="18" y="14" width="34" height="44" rx="4" fill="#ffffff" opacity="0.7" />
    <line x1="35" y1="14" x2="35" y2="58" stroke="#cbd5e1" strokeWidth="1.5" />
    <line x1="18" y1="36" x2="52" y2="36" stroke="#cbd5e1" strokeWidth="1.5" />

    {/* Patient seated comfortably */}
    <rect x="15" y="70" width="60" height="45" rx="8" fill="#94a3b8" opacity="0.3" />
    <circle cx="44" cy="52" r="13" fill="#fcd34d" />
    <path d="M34 48 C34 38 46 36 56 42" fill="#334155" />
    <path d="M30 92 C30 72 38 68 58 68 C64 78 62 92 62 92 Z" fill="#2563eb" />

    {/* Specialist Nurse */}
    <circle cx="106" cy="46" r="13" fill="#fcd34d" />
    <path d="M96 40 C98 30 110 30 118 36" fill="#1e293b" />
    {/* Mask */}
    <rect x="98" y="47" width="14" height="9" rx="3" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1" />
    {/* Stethoscope */}
    <path d="M98 65 Q92 78 106 82 Q118 78 114 65" stroke="#94a3b8" strokeWidth="2.5" fill="none" />
    <path d="M90 95 C90 70 100 66 122 66 C126 78 124 95 124 95 Z" fill="#0f766e" />

    {/* Medical Kit on Table */}
    <rect x="68" y="98" width="28" height="18" rx="4" fill="#047857" />
    <line x1="82" y1="102" x2="82" y2="112" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="77" y1="107" x2="87" y2="107" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
  </svg>
);
