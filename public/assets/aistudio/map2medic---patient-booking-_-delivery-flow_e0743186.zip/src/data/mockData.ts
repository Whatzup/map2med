import { CartItem, ServiceItem, Specialist, ServiceProgressItem } from '../types';

export const POPULAR_CATEGORIES = [
  { id: 'injections', name: 'Injections', icon: 'syringe', color: 'bg-emerald-50 text-emerald-700' },
  { id: 'wound', name: 'Wound Care', icon: 'bandage', color: 'bg-amber-50 text-amber-700' },
  { id: 'vitals', name: 'Vitals', icon: 'activity', color: 'bg-blue-50 text-blue-700' },
  { id: 'lab', name: 'Lab Tests', icon: 'flask-conical', color: 'bg-cyan-50 text-cyan-700' },
  { id: 'physio', name: 'Physio', icon: 'stretching', color: 'bg-teal-50 text-teal-700' },
  { id: 'elder', name: 'Elder Care', icon: 'heart-handshake', color: 'bg-indigo-50 text-indigo-700' },
];

export const INJECTION_SERVICES: ServiceItem[] = [
  {
    id: 'inj-1',
    title: 'Injection Administration',
    subtitle: 'Single Nurse Visit • At Home',
    price: 89,
    unit: 'session',
    category: 'injections',
    imageType: 'injection',
    duration: '20 mins',
    description: 'Sterile subcutaneous or intramuscular injection with disposable kit by verified registered nurse.'
  },
  {
    id: 'inj-2',
    title: 'IV Drip Setup',
    subtitle: 'Complete Saline / IV Infusion',
    price: 122,
    unit: 'shot',
    category: 'injections',
    imageType: 'iv-drip',
    duration: '45 mins',
    description: 'IV cannulation, fluid infusion setup, and continuous vitals monitoring during the session.'
  },
  {
    id: 'inj-3',
    title: 'Vaccination',
    subtitle: 'Flu, Hepatitis, Tetanus & Routine',
    price: 146,
    unit: 'dose',
    category: 'injections',
    imageType: 'vaccine',
    duration: '25 mins',
    description: 'Cold-chain preserved vaccine administration with post-vaccination observation.'
  },
  {
    id: 'inj-4',
    title: 'IM / IV Injection',
    subtitle: 'Antibiotics & Specialized Doses',
    price: 122,
    unit: 'session',
    category: 'injections',
    imageType: 'im-injection',
    duration: '30 mins',
    description: 'Physician-prescribed antibiotic or specialty drug administration with allergy screening.'
  }
];

export const INITIAL_CART_ITEMS: CartItem[] = [
  {
    service: {
      id: 'inj-admin',
      title: 'Injection Administration',
      subtitle: 'One Time',
      price: 99,
      unit: 'session',
      category: 'injections',
      imageType: 'injection',
      duration: '20 mins'
    },
    quantity: 1
  },
  {
    service: {
      id: 'lab-blood',
      title: 'Lab Test (Blood)',
      subtitle: 'Basic Panel (12 Tests) / At Home',
      price: 499,
      unit: 'test',
      category: 'lab',
      imageType: 'blood-test',
      duration: '15 mins'
    },
    quantity: 1
  },
  {
    service: {
      id: 'physio-sesh',
      title: 'Physio Session',
      subtitle: 'Home Visit / 45 Mins',
      price: 399,
      unit: 'session',
      category: 'physio',
      imageType: 'physio',
      duration: '45 mins'
    },
    quantity: 1
  }
];

export const ASSIGNED_SPECIALIST: Specialist = {
  name: 'Amit Kumar',
  role: 'Senior Care Specialist & RN',
  rating: 4.8,
  reviewCount: 136,
  experience: '5+ years',
  phone: '+91 98712 34567',
  avatarUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&auto=format&fit=crop&q=80',
  vehicle: 'Hero Electric Optima (Green)',
  plateNumber: 'HR-26-EM-4821',
  distance: '1.4 km away',
  etaMinutes: 18
};

export const INITIAL_SERVICE_PROGRESS: ServiceProgressItem[] = [
  {
    id: 'sp-1',
    title: 'Injection Administration',
    category: 'injections',
    status: 'in_progress',
    timeEstimate: 'Started 3 mins ago'
  },
  {
    id: 'sp-2',
    title: 'Lab Test (Blood)',
    category: 'lab',
    status: 'pending',
    timeEstimate: 'Next in sequence'
  },
  {
    id: 'sp-3',
    title: 'Physio Session',
    category: 'physio',
    status: 'pending',
    timeEstimate: 'Awaiting completion of vitals'
  }
];

export const MATCHING_CRITERIA = [
  {
    id: 'skills',
    title: 'Skills & Expertise',
    desc: 'Matching certified nursing & phlebotomy specialists',
    icon: 'badge-check'
  },
  {
    id: 'service',
    title: 'Service Ability',
    desc: 'Verifying equipment & sterile kit capability',
    icon: 'stethoscope'
  },
  {
    id: 'distance',
    title: 'Distance',
    desc: 'Finding the nearest available care specialists in DLF 5',
    icon: 'map-pin'
  },
  {
    id: 'availability',
    title: 'Availability',
    desc: 'Confirming instant slot confirmation & on-time arrival',
    icon: 'calendar-clock'
  }
];

export const ADDRESSES = [
  { id: 'home', label: 'HOME', address: 'BIS DLF Phase 5, Gurugram', isDefault: true },
  { id: 'work', label: 'WORK', address: 'Cyber City, Tower B, Gurugram', isDefault: false },
  { id: 'parents', label: "PARENTS' HOME", address: 'Sector 43, Golf Course Road, Gurugram', isDefault: false },
];
